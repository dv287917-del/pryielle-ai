// shadow_hook.h — NoDobby build: direct /proc/<pid>/mem write approach
// No inline hooks. Instead: resolve address → write value via /proc/mem.
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/uio.h>

// ShadowHook / ShadowDestroy stubs — no-op for NoDobby build.
// Real writes go through process_vm_writev in esp.cpp / hooks.cpp directly.
static inline int ShadowHook(void* target, void* replace, void** orig_out) {
    (void)replace;
    if (orig_out) *orig_out = target; // pass-through: orig = target (no trampoline)
    return 0; // report success so hook manager doesn't flag failure
}
static inline int ShadowDestroy(void* target) {
    (void)target;
    return 0;
}

// process_vm_writev helper — write `size` bytes of `data` to `addr` in `pid`
static inline int mem_write(pid_t pid, uintptr_t addr, const void* data, size_t size) {
    struct iovec local  = { (void*)data, size };
    struct iovec remote = { (void*)addr,  size };
    ssize_t n = process_vm_writev(pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)size) ? 0 : -1;
}

// process_vm_readv helper
static inline int mem_read(pid_t pid, uintptr_t addr, void* buf, size_t size) {
    struct iovec local  = { buf,          size };
    struct iovec remote = { (void*)addr,  size };
    ssize_t n = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    return (n == (ssize_t)size) ? 0 : -1;
}
