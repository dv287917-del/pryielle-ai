import os, re, sys

# ─────────────────────────────────────────────────────────────────────────────
# THE ACTUAL PROBLEM (from build logs):
#
#   os_arch_features.h  defines  struct OSMemory { PageSize() }
#                        defines  static const int kReadExecute = ...
#   platform.h          defines  class OSMemory { Allocate/Free/Release/... }
#                        defines  enum MemoryPermission { kReadExecute = ... }
#
#   Both get included in the same TU → redefinition explosion.
#
# THE FIX:
#   Strip os_arch_features.h of its OSMemory struct and kReadExecute const.
#   platform.h's full class is what the whole codebase actually needs.
#   platform-posix.cc's out-of-line definitions match platform.h's class.
# ─────────────────────────────────────────────────────────────────────────────

OS_ARCH_H = "/tmp/Dobby/common/os_arch_features.h"
POSIX_CC  = "/tmp/Dobby/source/Backend/UserMode/UnifiedInterface/platform-posix.cc"

# ── 1. os_arch_features.h ────────────────────────────────────────────────────
if os.path.exists(OS_ARCH_H):
    with open(OS_ARCH_H) as f:
        src = f.read()

    if "OSMEM_STRIPPED" not in src:
        original = src

        # Remove: struct OSMemory { ... };  (single-line or multi-line)
        src = re.sub(
            r'struct\s+OSMemory\s*\{[^}]*\}\s*;',
            '/* OSMemory stripped by patch_osmem.py */',
            src,
            flags=re.DOTALL
        )

        # Remove: static const int kReadExecute = ...;
        src = re.sub(
            r'static\s+const\s+int\s+kReadExecute\s*=\s*[^;]+;',
            '/* kReadExecute stripped by patch_osmem.py */',
            src
        )

        # Mark done
        src = "// OSMEM_STRIPPED\n" + src

        with open(OS_ARCH_H, 'w') as f:
            f.write(src)
        print("Patched: os_arch_features.h (stripped conflicting defs)")
    else:
        print("Already done: os_arch_features.h")
else:
    print("MISSING: " + OS_ARCH_H)
    sys.exit(1)

# ── 2. platform-posix.cc ─────────────────────────────────────────────────────
# This file's out-of-line definitions need the full OSMemory class from
# platform.h. It already includes platform.h (that's fine). We just need
# os_arch_features.h to NOT define a conflicting struct before platform.h
# arrives — which step 1 above handles.
#
# BUT: the file also has its own prepended stub from a previous bad patch run.
# Strip any OSMEMORY_STUB block that may have been prepended.
if os.path.exists(POSIX_CC):
    with open(POSIX_CC) as f:
        src = f.read()

    if "OSMEMORY_STUB" in src:
        # Remove the entire prepended stub block
        src = re.sub(
            r'// OSMEMORY_STUB.*?#endif\s*\n',
            '',
            src,
            flags=re.DOTALL
        )
        # Also handle the ifndef/define/endif guard form
        src = re.sub(
            r'#ifndef OSMEMORY_STUB.*?#endif\s*//\s*OSMEMORY_STUB\s*\n',
            '',
            src,
            flags=re.DOTALL
        )
        # Fallback: strip the raw struct if it somehow remains
        src = re.sub(
            r'struct OSMemory \{[^}]*\}\s*;\s*\nstatic const int kReadExecute[^\n]+\n',
            '',
            src,
            flags=re.DOTALL
        )
        with open(POSIX_CC, 'w') as f:
            f.write(src)
        print("Cleaned: platform-posix.cc (removed bad stub)")
    else:
        print("Clean: platform-posix.cc (no stub found)")
else:
    print("MISSING: " + POSIX_CC)
    sys.exit(1)

print("patch_osmem done — os_arch_features.h stripped, platform.h owns OSMemory")
