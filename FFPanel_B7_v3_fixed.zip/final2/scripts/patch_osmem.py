import os, re

PLATFORM_H = "/tmp/Dobby/source/PlatformUnifiedInterface/platform.h"
OS_ARCH_H  = "/tmp/Dobby/common/os_arch_features.h"
POSIX_CC   = "/tmp/Dobby/source/Backend/UserMode/UnifiedInterface/platform-posix.cc"

# ── 1. platform.h ──────────────────────────────────────────────────────────────
# Wrap the OSMemory class and kReadExecute enum in platform.h with guards so
# they yield to whatever os_arch_features.h defined first.
if os.path.exists(PLATFORM_H):
    with open(PLATFORM_H) as f:
        src = f.read()

    if "PLATFORM_H_OSMEMORY_GUARDED" not in src:
        # Guard kReadExecute inside MemoryPermission enum (it's defined as an
        # enumerator there, so we guard the whole enum block).
        src = src.replace(
            "enum MemoryPermission {",
            "#ifndef PLATFORM_H_OSMEMORY_GUARDED\nenum MemoryPermission {"
        )
        # Find the OSMemory class end and close the guard after it.
        # We inject #endif right before the last #endif of the file or at EOF.
        # Safer: inject right after the closing brace of class OSMemory.
        src = re.sub(
            r'(class OSMemory \{.*?\};)',
            r'\1\n#define PLATFORM_H_OSMEMORY_GUARDED\n#endif // PLATFORM_H_OSMEMORY_GUARDED',
            src,
            count=1,
            flags=re.DOTALL
        )
        with open(PLATFORM_H, 'w') as f:
            f.write(src)
        print("Patched: platform.h")
    else:
        print("Already done: platform.h")

# ── 2. os_arch_features.h ──────────────────────────────────────────────────────
# Replace the conflicting flat definitions with a full OSMemory struct that
# matches what platform-posix.cc expects (Allocate, Free, Release, SetPermission,
# PageSize) — but only if platform.h hasn't already defined it.
OSMEM_BLOCK = r"""
#ifndef PLATFORM_H_OSMEMORY_GUARDED
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>

enum MemoryPermission {
  kNoAccess      = 0,
  kRead          = PROT_READ,
  kReadWrite     = PROT_READ | PROT_WRITE,
  kReadWriteExecute = PROT_READ | PROT_WRITE | PROT_EXEC,
  kReadExecute   = PROT_READ | PROT_EXEC,
};

struct OSMemory {
  static size_t PageSize() { return (size_t)sysconf(_SC_PAGESIZE); }
  static void*  Allocate(size_t size, MemoryPermission access, void* fixed = nullptr);
  static bool   Free(void* address, size_t size);
  static bool   Release(void* address, size_t size);
  static bool   SetPermission(void* address, size_t size, MemoryPermission access);
};
static const int kReadExecute = PROT_READ | PROT_EXEC;
#define PLATFORM_H_OSMEMORY_GUARDED
#endif // PLATFORM_H_OSMEMORY_GUARDED
"""

if os.path.exists(OS_ARCH_H):
    with open(OS_ARCH_H) as f:
        src = f.read()
    if "PLATFORM_H_OSMEMORY_GUARDED" not in src:
        # Strip any old conflicting definitions
        src = re.sub(r'static const int kReadExecute\s*=.*?;', '', src)
        src = re.sub(r'struct OSMemory\s*\{[^}]*\};', '', src, flags=re.DOTALL)
        with open(OS_ARCH_H, 'w') as f:
            f.write(OSMEM_BLOCK + src)
        print("Patched: os_arch_features.h")
    else:
        print("Already done: os_arch_features.h")

# ── 3. platform-posix.cc ──────────────────────────────────────────────────────
# This file has the out-of-line definitions for OSMemory::Allocate/Free/Release/
# SetPermission. It must NOT re-include the guard-blocked declarations, so just
# ensure it includes os_arch_features.h before platform.h pulls in the guarded
# block. The file already includes dobby_internal.h which pulls platform.h —
# we prepend a direct include of os_arch_features.h so our struct wins first.
if os.path.exists(POSIX_CC):
    with open(POSIX_CC) as f:
        src = f.read()
    guard_include = '#include "../../../../common/os_arch_features.h"\n'
    if guard_include not in src and "os_arch_features.h" not in src:
        with open(POSIX_CC, 'w') as f:
            f.write(guard_include + src)
        print("Patched: platform-posix.cc")
    else:
        print("Already done: platform-posix.cc")

print("patch_osmem done")
