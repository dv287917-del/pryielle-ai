package com.antitheft.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnStartPanel).setOnClickListener {
            startActivity(Intent(this, DecoyActivity::class.java))
        }
        findViewById<Button>(R.id.btnSecret).setOnClickListener {
            startActivity(Intent(this, SecretActivity::class.java))
        }
    }
}
