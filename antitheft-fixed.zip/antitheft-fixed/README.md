# AntiTheft App

## Tujhe kya karna hai — sirf 3 steps

---

### STEP 1 — Backend deploy (Render)

1. [render.com](https://render.com) pe account banao (free)
2. New → Web Service → "Connect a GitHub repo" → is repo ko select karo
3. Settings:
   - **Root Directory:** `backend`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
4. **Service name: `antitheft-admin`** (exactly yahi likhna)
5. Deploy karo — 2-3 min lagenge

---

### STEP 2 — APK build

1. Poora project GitHub pe push karo (main branch)
2. GitHub → Actions tab → "Build APK" → wait karo ~5 min
3. Artifacts → `antitheft-apk.zip` download karo → `.apk` nikalo
4. Phone pe: Settings → Install unknown apps → allow → install karo

---

### STEP 3 — Admin panel

Browser mein kholo:
```
https://antitheft-admin.onrender.com/admin
```

Login:
- Username: `admin`
- Password: `Th1ef@2303Secure`

Photos yahan dikhenge jab app trigger hoga.

---

## App kaise kaam karta hai

| Button | Kya hota hai |
|--------|-------------|
| Start Panel | "Fail to Start" dikhata hai (decoy) |
| Secret → 2303 | Front + back photo silently upload |

