# ⚡ FF Glory Bot

Complete system — Key Management + Flutter App + FF Bot + Telegram Bot

---

## 📁 Structure

```
ff-glory-bot/
├── bot/              → Node.js FF Bot
├── backend/          → Python FastAPI (Key System)
├── admin-panel/      → HTML Admin Panel
├── telegram-bot/     → Python Telegram Bot
└── flutter-app/      → Android App
```

---

## 🚀 Setup Order

### 1. Firebase Setup
- Go to https://console.firebase.google.com
- Create project → Enable Firestore
- Project Settings → Service Accounts → Generate Key
- Save as `backend/firebase_key.json`

### 2. Backend (FastAPI)
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Edit .env — set ADMIN_TOKEN to any secret string
uvicorn main:app --host 0.0.0.0 --port 8000
```
Deploy on Railway.app or Render.com (free tier works)

### 3. Telegram Bot
```bash
cd telegram-bot
pip install -r requirements.txt
cp .env.example .env
# Edit .env:
#   TELEGRAM_BOT_TOKEN = from @BotFather
#   ADMIN_IDS = your Telegram user ID (get from @userinfobot)
#   BACKEND_URL = your deployed backend URL
#   ADMIN_TOKEN = same token as backend
python bot.py
```

### 4. Admin Panel
- Open `admin-panel/index.html` in browser
- Enter Backend URL and Admin Token
- Done — generate keys from here

### 5. Flutter App
```bash
cd flutter-app
# Edit lib/config.dart — set backendUrl to your backend
flutter pub get
flutter build apk --release
# APK at: build/app/outputs/flutter-apk/app-release.apk
```

### 6. FF Bot
```bash
cd bot
npm install
# Edit config.json:
#   accounts → your bot FF accounts (UID + Password)
#   target_guild_id → your guild ID
node index.js 10    # runs 10 matches
```

---

## 📱 GitHub Actions APK Build

Create `.github/workflows/build.yml`:

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.16.0'
      - run: cd flutter-app && flutter pub get
      - run: cd flutter-app && flutter build apk --release
      - uses: actions/upload-artifact@v3
        with:
          name: app-release.apk
          path: flutter-app/build/app/outputs/flutter-apk/app-release.apk
```

---

## ⚙️ Config Files to Edit

| File | What to change |
|------|---------------|
| `backend/.env` | ADMIN_TOKEN |
| `telegram-bot/.env` | BOT_TOKEN, ADMIN_IDS, BACKEND_URL, ADMIN_TOKEN |
| `flutter-app/lib/config.dart` | backendUrl |
| `bot/config.json` | accounts, target_guild_id |
| `backend/firebase_key.json` | Your Firebase credentials |

---

## 🔑 Key Flow

```
Admin Panel → Generate Key → Give to user
User → Opens App → Enters Key → Verified with Backend
User → Opens Guild Bot → Enter Guild ID → Start
```
