# telegram bot.py — FF Glory Bot Telegram Interface

import os
import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x]
BACKEND_URL = os.getenv("BACKEND_URL", "").rstrip("/")
ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "")

PRICES = {
    7: 49,
    15: 89,
    20: 119,
    30: 149
}

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

def backend_headers():
    return {"Authorization": f"Bearer {ADMIN_TOKEN}"}

# ─── User Commands ─────────────────────────────────────

async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "⚡ *FF Glory Bot*\n\n"
        "Commands:\n"
        "/buy — Key plans & prices\n"
        "/activate KEY — Activate your key\n"
        "/status KEY — Check key status\n"
        "/help — Help",
        parse_mode="Markdown"
    )

async def buy(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    msg = "🔑 *Key Plans*\n\n"
    for days, price in PRICES.items():
        msg += f"• *{days} Days* — ₹{price}\n"
    msg += "\nContact admin to purchase."
    await update.message.reply_text(msg, parse_mode="Markdown")

async def activate(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        await update.message.reply_text("Usage: /activate YOUR_KEY")
        return
    
    key = ctx.args[0].upper().strip()
    device_id = str(update.effective_user.id)  # Use Telegram ID as device ID
    
    try:
        res = requests.post(
            f"{BACKEND_URL}/verify-key",
            params={"key": key, "device_id": device_id},
            timeout=10
        )
        data = res.json()
        
        if res.status_code == 200:
            await update.message.reply_text(
                f"✅ *Key Activated!*\n\n"
                f"Valid for: *{data['days_left']} days*\n"
                f"Expires: {data['expiry']}",
                parse_mode="Markdown"
            )
        else:
            await update.message.reply_text(f"❌ {data.get('detail', 'Invalid key')}")
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def status(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        await update.message.reply_text("Usage: /status YOUR_KEY")
        return
    
    key = ctx.args[0].upper().strip()
    device_id = str(update.effective_user.id)
    
    try:
        res = requests.get(
            f"{BACKEND_URL}/key-status",
            params={"key": key, "device_id": device_id},
            timeout=10
        )
        data = res.json()
        
        if res.status_code == 200:
            status_emoji = "✅" if data["valid"] else "❌"
            await update.message.reply_text(
                f"{status_emoji} *Key Status*\n\n"
                f"Valid: {data['valid']}\n"
                f"Days Left: {data['days_left']}\n"
                f"Expires: {data['expiry']}",
                parse_mode="Markdown"
            )
        else:
            await update.message.reply_text(f"❌ {data.get('detail', 'Not found')}")
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

# ─── Admin Commands ────────────────────────────────────

async def genkey(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only")
        return
    
    if not ctx.args:
        await update.message.reply_text("Usage: /genkey 30")
        return
    
    days = int(ctx.args[0])
    if days not in PRICES:
        await update.message.reply_text(f"Days must be: {list(PRICES.keys())}")
        return
    
    try:
        res = requests.post(
            f"{BACKEND_URL}/admin/generate-key",
            params={"days": days},
            headers=backend_headers(),
            timeout=10
        )
        data = res.json()
        
        if res.status_code == 200:
            await update.message.reply_text(
                f"🔑 *Key Generated*\n\n"
                f"`{data['key']}`\n\n"
                f"Days: {data['days']}\n"
                f"Expires: {data['expiry']}",
                parse_mode="Markdown"
            )
        else:
            await update.message.reply_text(f"❌ {data.get('detail')}")
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def keys(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only")
        return
    
    try:
        res = requests.get(
            f"{BACKEND_URL}/admin/keys",
            headers=backend_headers(),
            timeout=10
        )
        all_keys = res.json()
        
        if not all_keys:
            await update.message.reply_text("No keys found")
            return
        
        active = [k for k in all_keys if not k["expired"] and k["used"]]
        unused = [k for k in all_keys if not k["expired"] and not k["used"]]
        expired = [k for k in all_keys if k["expired"]]
        
        msg = f"📊 *Key Overview*\n\n"
        msg += f"Active: {len(active)} | Unused: {len(unused)} | Expired: {len(expired)}\n\n"
        
        for k in all_keys[:15]:  # Show max 15
            status = "✅" if (k["used"] and not k["expired"]) else ("⏳" if not k["used"] else "❌")
            msg += f"{status} `{k['key']}` — {k['days_left']}d left\n"
        
        if len(all_keys) > 15:
            msg += f"\n...and {len(all_keys) - 15} more"
        
        await update.message.reply_text(msg, parse_mode="Markdown")
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

async def delkey(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Admin only")
        return
    
    if not ctx.args:
        await update.message.reply_text("Usage: /delkey KEY")
        return
    
    key = ctx.args[0].upper().strip()
    
    try:
        res = requests.delete(
            f"{BACKEND_URL}/admin/delete-key/{key}",
            headers=backend_headers(),
            timeout=10
        )
        if res.status_code == 200:
            await update.message.reply_text(f"✅ Key deleted: `{key}`", parse_mode="Markdown")
        else:
            await update.message.reply_text(f"❌ {res.json().get('detail')}")
    except Exception as e:
        await update.message.reply_text(f"❌ Error: {str(e)}")

# ─── Main ─────────────────────────────────────────────

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("buy", buy))
    app.add_handler(CommandHandler("activate", activate))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("genkey", genkey))
    app.add_handler(CommandHandler("keys", keys))
    app.add_handler(CommandHandler("delkey", delkey))
    
    print("Bot running...")
    app.run_polling()

if __name__ == "__main__":
    main()
