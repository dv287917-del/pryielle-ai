import os, sys

# The osbase submodule compiles platform-posix.cc which conflicts with
# platform.h when the submodule brings its own headers.
# Fix: replace osbase/CMakeLists.txt with a stub that builds an empty target.
# Dobby's main build still compiles platform-posix.cc correctly.

OSBASE_CMAKE = "/tmp/Dobby/external/osbase/CMakeLists.txt"

if not os.path.exists(OSBASE_CMAKE):
    print("MISSING: " + OSBASE_CMAKE)
    sys.exit(1)

stub = """add_library(osbase STATIC)
set_target_properties(osbase PROPERTIES LINKER_LANGUAGE CXX)
"""

with open(OSBASE_CMAKE, 'w') as f:
    f.write(stub)

print("patch_osmem: osbase neutralized — no duplicate compilation")
