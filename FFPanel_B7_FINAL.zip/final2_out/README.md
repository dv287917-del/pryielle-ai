# FFPanel B7

Free Fire India — ESP + Headshot + Safe Mode panel.  
Root required: Magisk + Zygisk + Shamiko.

---

## Batch status

| Batch | Feature | Status |
|-------|---------|--------|
| B1 | Root check + injector shell | ✅ |
| B2 | Anti-ban (Shamiko, DenyList, ProcessSpoof, MapsHide) | ✅ |
| B3 | ptrace + memfd SO injector | ✅ |
| B4 | Hook setup + offset config loader | ✅ |
| B5 | Headshot bone redirect + damage multiplier | ✅ |
| B6 | ESP overlay (corner box, head dot, snap line, distance) | ✅ |
| B7 | Safe mode toggle + panel UI + live stats | ✅ |

---

## GitHub se APK banana — step by step

### Step 1: Dobby .a files daalo

Yeh binary files hain, repo mein commit karni padti hain:

```
jni/dobby/lib/arm64-v8a/libdobby.a
jni/dobby/lib/armeabi-v7a/libdobby.a
```

Build karo (Linux/Mac pe):
```bash
git clone https://github.com/jmpews/Dobby
cd Dobby

# arm64-v8a
cmake -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake \
      -DANDROID_ABI=arm64-v8a \
      -DANDROID_PLATFORM=android-28 \
      -DCMAKE_BUILD_TYPE=Release \
      -B build_arm64
cmake --build build_arm64
cp build_arm64/libdobby.a /path/to/FFPanel_B7/jni/dobby/lib/arm64-v8a/

# armeabi-v7a
cmake -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake \
      -DANDROID_ABI=armeabi-v7a \
      -DANDROID_PLATFORM=android-28 \
      -DCMAKE_BUILD_TYPE=Release \
      -B build_v7a
cmake --build build_v7a
cp build_v7a/libdobby.a /path/to/FFPanel_B7/jni/dobby/lib/armeabi-v7a/
```

### Step 2: GitHub pe upload karo

1. GitHub pe naya repo banao (private recommended)
2. Poora `FFPanel_B7/` folder upload karo (zip se extract karke)
3. Dobby `.a` files bhi include karo (Step 1 se)

### Step 3: GitHub Actions se build

1. Repo mein jao → **Actions** tab
2. **Build FFPanel APK** workflow dikhega
3. **Run workflow** → Run
4. Build complete hone ke baad → **Artifacts** mein:
   - `FFPanel-debug-<N>` → debug APK
   - `FFPanel-release-<N>` → release APK
5. Download karo, device pe install karo

> `gradle-wrapper.jar` ki zaroorat nahi — CI automatically handle karta hai.

---

## Device setup

1. Magisk + Zygisk + Shamiko installed + enabled
2. Free Fire run karke background mein daalo
3. `offsets.json` push karo:
   ```bash
   adb shell mkdir -p /sdcard/FFPanel
   adb push offsets.json /sdcard/FFPanel/offsets.json
   ```
4. Offsets fill karo apne OB version ke liye (Ghidra / il2cpp dump se)
5. FFPanel APK install karo
6. App open karo → overlay permission grant karo
7. **INJECT** dabao

---

## Safe Mode

**Safe Mode ON** karo jab lagta ho AC scan ho raha hai.  
Headshot redirect + ESP draw dono ruk jaata hai bina eject kiye.  
Baad mein wapas toggle OFF karo — sab wapis shuru.

---

## offsets.json

Device pe `/sdcard/FFPanel/offsets.json` pe hona chahiye inject se pehle:

```json
{
  "il2cpp": {
    "BulletDamage":            "0x...",
    "CharacterBone_GetPos":    "0x...",
    "EntityManager_GetList":   "0x...",
    "ViewMatrix":              "0x...",
    "WorldToScreen":           "0x...",
    "LocalPlayer_GetInstance": "0x..."
  }
}
```
