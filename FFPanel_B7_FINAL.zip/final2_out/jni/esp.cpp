// FFPanel — B6 esp.cpp
// Entity reader + WorldToScreen projection
// Compiled into ffcheat.so alongside hooks.cpp
//
// Reads live entity list via hooked EntityGetList pointer (stored in hooks.cpp).
// Projects bone positions to screen via ViewMatrix + W2S.
// Exports nativeGetEspFrames() to Kotlin for overlay drawing.

#include <jni.h>
#include <android/log.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#define TAG  "FFPanel_ESP"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Shared with hooks.cpp ────────────────────────────────────────────────────
// Declared extern — defined in hooks.cpp, linked together into ffcheat.so
extern void* orig_EntityGetList;
extern void* orig_ViewMatrix;
extern void* orig_W2S;
extern void* orig_BoneGetPos;

// ── Types ────────────────────────────────────────────────────────────────────
typedef struct { float x, y, z; }       Vec3;
typedef struct { float x, y; }          Vec2;
typedef struct { float m[4][4]; }        Mat4;

// Bone IDs — keep in sync with hooks.cpp defines
#define BONE_HEAD   0
#define BONE_CHEST  2
#define BONE_LFOOT  10
#define BONE_RFOOT  11

// Max entities we process per frame — cap to bound JNI array size
#define MAX_ENTITIES 32

// ── Function pointer types ───────────────────────────────────────────────────
typedef void*  (*EntityGetList_t)(void* entityMgr);
typedef Vec3*  (*BoneGetPos_t)(void* charObj, int boneId);
typedef Mat4*  (*ViewMatrix_t)(void* camera);

// W2S signature: takes Vec3 world pos + Mat4 view, writes Vec2 screen pos,
// returns bool (true = in front of camera)
typedef bool   (*WorldToScreen_t)(Vec3* worldPos, Mat4* viewMat, Vec2* outScreen,
                                   float screenW, float screenH);

// ── Screen dimensions — set once from Kotlin after overlay init ──────────────
static float g_screen_w = 1280.0f;
static float g_screen_h = 720.0f;

// ── Entity manager pointer — written by hook_EntityGetList on first call ─────
static void* g_entity_manager = nullptr;

// ── Camera pointer — written by hook_ViewMatrix on first call ───────────────
static void* g_camera = nullptr;

// ── Frame data written by nativeGetEspFrames, read by Kotlin ────────────────
// One EspFrame per visible enemy
typedef struct {
    float headX,  headY;    // screen-space head position
    float footX,  footY;    // screen-space foot midpoint
    float boxW,   boxH;     // bounding box width / height in px
    float dist;             // world-space distance from local player (metres)
    int   valid;            // 1 = in front of camera and on screen
} EspFrame;

static EspFrame g_frames[MAX_ENTITIES];
static int      g_frame_count = 0;

// ════════════════════════════════════════════════════════════════════════════
// Helpers
// ════════════════════════════════════════════════════════════════════════════

// Updated by hook_EntityGetList so we always have the live manager ptr
extern "C" void esp_on_entity_list(void* entityMgr) {
    g_entity_manager = entityMgr;
}

// Updated by hook_ViewMatrix
extern "C" void esp_on_camera(void* camera) {
    g_camera = camera;
}

static float vec3_dist(Vec3* a, Vec3* b) {
    float dx = a->x - b->x, dy = a->y - b->y, dz = a->z - b->z;
    return sqrtf(dx*dx + dy*dy + dz*dz);
}

// ── Entity list layout assumptions ──────────────────────────────────────────
// Free Fire uses a Unity EntityManager. The list is typically:
//   struct EntityList { void** entities; int count; }
// at the pointer returned by EntityGetList. Adjust offsets if your build differs.
#define ENTITY_LIST_PTR_OFFSET  0x08   // offset to void** array inside list obj
#define ENTITY_LIST_COUNT_OFFSET 0x10  // offset to int count

static void** get_entity_array(void* listObj, int* out_count) {
    if (!listObj) return nullptr;
    void** arr   = *(void***)((uint8_t*)listObj + ENTITY_LIST_PTR_OFFSET);
    int    count = *(int*)   ((uint8_t*)listObj + ENTITY_LIST_COUNT_OFFSET);
    if (!arr || count <= 0 || count > 512) return nullptr;
    *out_count = count;
    return arr;
}

// ── Local player pointer — read from singleton via LocalPlayer_GetInstance ───
// Stored once after first successful read; re-read if null.
static void* g_local_player = nullptr;

// LocalPlayer_GetInstance — addr stored separately, set via nativeSetLocalPlayerAddr
static void* g_local_player_fn = nullptr;
typedef void* (*LocalPlayerGet_t)();

static void* get_local_player() {
    if (g_local_player) return g_local_player;
    if (!g_local_player_fn) return nullptr;
    g_local_player = ((LocalPlayerGet_t)g_local_player_fn)();
    return g_local_player;
}

// ════════════════════════════════════════════════════════════════════════════
// Core: build ESP frames for current tick
// Called from nativeGetEspFrames — runs on the UI thread polling loop
// ════════════════════════════════════════════════════════════════════════════
static int build_frames() {
    if (!g_entity_manager || !g_camera) return 0;
    if (!orig_BoneGetPos || !orig_ViewMatrix || !orig_W2S) return 0;

    // Get view matrix
    Mat4* viewMat = ((ViewMatrix_t)orig_ViewMatrix)(g_camera);
    if (!viewMat) return 0;

    // Get entity list
    void* listObj = ((EntityGetList_t)orig_EntityGetList)(g_entity_manager);
    if (!listObj) return 0;

    int count = 0;
    void** entities = get_entity_array(listObj, &count);
    if (!entities) return 0;

    void* localPlayer = get_local_player();

    int frameIdx = 0;
    int limit = count < MAX_ENTITIES ? count : MAX_ENTITIES;

    for (int i = 0; i < limit && frameIdx < MAX_ENTITIES; i++) {
        void* entity = entities[i];
        if (!entity) continue;
        if (entity == localPlayer) continue;   // skip self

        // Get head + foot bone positions
        Vec3* headPos  = ((BoneGetPos_t)orig_BoneGetPos)(entity, BONE_HEAD);
        Vec3* lFootPos = ((BoneGetPos_t)orig_BoneGetPos)(entity, BONE_LFOOT);
        Vec3* rFootPos = ((BoneGetPos_t)orig_BoneGetPos)(entity, BONE_RFOOT);
        if (!headPos || !lFootPos || !rFootPos) continue;

        // Foot midpoint
        Vec3 footMid = {
            (lFootPos->x + rFootPos->x) * 0.5f,
            (lFootPos->y + rFootPos->y) * 0.5f,
            (lFootPos->z + rFootPos->z) * 0.5f
        };

        // Project to screen
        Vec2 headScreen, footScreen;
        bool headVis = ((WorldToScreen_t)orig_W2S)(headPos,  viewMat, &headScreen, g_screen_w, g_screen_h);
        bool footVis = ((WorldToScreen_t)orig_W2S)(&footMid, viewMat, &footScreen, g_screen_w, g_screen_h);

        if (!headVis || !footVis) continue;
        // Clamp to screen bounds
        if (headScreen.x < 0 || headScreen.x > g_screen_w) continue;
        if (headScreen.y < 0 || headScreen.y > g_screen_h) continue;

        // Box dimensions: height = foot.y - head.y, width = height * 0.4
        float boxH = footScreen.y - headScreen.y;
        if (boxH < 2.0f) continue;   // degenerate
        float boxW = boxH * 0.4f;

        // Distance from local player
        float dist = localPlayer
            ? vec3_dist(headPos, ((BoneGetPos_t)orig_BoneGetPos)(localPlayer, BONE_HEAD))
            : 0.0f;

        EspFrame* f = &g_frames[frameIdx++];
        f->headX = headScreen.x;
        f->headY = headScreen.y;
        f->footX = footScreen.x;
        f->footY = footScreen.y;
        f->boxW  = boxW;
        f->boxH  = boxH;
        f->dist  = dist;
        f->valid = 1;
    }

    return frameIdx;
}

// ════════════════════════════════════════════════════════════════════════════
// JNI exports
// ════════════════════════════════════════════════════════════════════════════

// Called once from EspOverlay.kt after WindowManager overlay is sized
extern "C" JNIEXPORT void JNICALL
Java_com_ffpanel_esp_EspRenderer_nativeSetScreenSize(
        JNIEnv*, jclass, jfloat w, jfloat h)
{
    g_screen_w = w;
    g_screen_h = h;
    LOGI("Screen size: %.0f × %.0f", w, h);
}

// Set LocalPlayer_GetInstance function address (from offsets.json)
extern "C" JNIEXPORT void JNICALL
Java_com_ffpanel_esp_EspRenderer_nativeSetLocalPlayerAddr(
        JNIEnv*, jclass, jlong addr)
{
    g_local_player_fn = (void*)addr;
    g_local_player    = nullptr;   // reset cache
    LOGI("LocalPlayer fn: %p", g_local_player_fn);
}

/**
 * Builds ESP frames for current tick and writes them into a flat float array.
 *
 * Layout per entity (8 floats):
 *   [0] headX  [1] headY
 *   [2] footX  [3] footY
 *   [4] boxW   [5] boxH
 *   [6] dist   [7] valid (1.0 or 0.0)
 *
 * Returns number of valid entities written.
 * Kotlin side pre-allocates FloatArray(MAX_ENTITIES * 8) and passes it in.
 */
extern "C" JNIEXPORT jint JNICALL
Java_com_ffpanel_esp_EspRenderer_nativeGetEspFrames(
        JNIEnv* env, jclass, jfloatArray outArr, jint maxEntities)
{
    int count = build_frames();
    if (count == 0) return 0;

    int limit = count < (int)maxEntities ? count : (int)maxEntities;

    jfloat* buf = env->GetFloatArrayElements(outArr, nullptr);
    if (!buf) return 0;

    for (int i = 0; i < limit; i++) {
        EspFrame* f = &g_frames[i];
        int base = i * 8;
        buf[base+0] = f->headX;
        buf[base+1] = f->headY;
        buf[base+2] = f->footX;
        buf[base+3] = f->footY;
        buf[base+4] = f->boxW;
        buf[base+5] = f->boxH;
        buf[base+6] = f->dist;
        buf[base+7] = (float)f->valid;
    }

    env->ReleaseFloatArrayElements(outArr, buf, 0);
    return limit;
}
