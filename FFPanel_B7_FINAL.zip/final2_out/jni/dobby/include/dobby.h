#pragma once
// Dobby inline hook library header.
// Drop the real libdobby.a into lib/<abi>/ before building.
// Source: https://github.com/jmpews/Dobby
#ifdef __cplusplus
extern "C" {
#endif

/**
 * Hook `target` function with `replace`.
 * Writes original trampoline pointer into *orig_out.
 * Returns 0 on success.
 */
int DobbyHook(void* target, void* replace, void** orig_out);

/**
 * Remove hook installed on `target`.
 * Returns 0 on success.
 */
int DobbyDestroy(void* target);

#ifdef __cplusplus
}
#endif
