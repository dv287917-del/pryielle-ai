// FFPanel — B6 hooks.cpp
// Extends B5 — adds esp_on_entity_list / esp_on_camera callbacks
// into the two pass-through hooks so esp.cpp gets live pointers.
// Everything else is identical to B5.

#include <jni.h>
#include <android/log.h>
#include <stdint.h>
#include <string.h>
#include <stdatomic.h>
#include "dobby.h"

#define TAG  "FFPanel_Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

#define HOOK_DAMAGE      (1 << 0)
#define HOOK_BONE        (1 << 1)
#define HOOK_ENTITY      (1 << 2)
#define HOOK_VIEWMATRIX  (1 << 3)

#define BONE_HEAD   0
#define BONE_NECK   1

typedef struct { float x, y, z; } Vec3;

// ── Originals — also accessed extern by esp.cpp ──────────────────────────────
void* orig_BulletDamage  = nullptr;
void* orig_BoneGetPos    = nullptr;
void* orig_EntityGetList = nullptr;
void* orig_ViewMatrix    = nullptr;
void* orig_W2S           = nullptr;

static int g_installed = 0;

// Declared in esp.cpp
extern "C" void esp_on_entity_list(void* entityMgr);
extern "C" void esp_on_camera(void* camera);

// ── B5 state ─────────────────────────────────────────────────────────────────
static atomic_int g_headshot_enabled    = 1;
static atomic_int g_dmg_multiplier_x10  = 10;
static atomic_int g_stat_dmg_calls      = 0;
static atomic_int g_stat_redirects      = 0;
static atomic_int g_stat_bone_queries   = 0;

// ════════════════════════════════════════════════════════════════════════════
// Hook implementations
// ════════════════════════════════════════════════════════════════════════════

typedef float (*BulletDamage_t)(void* bulletComp, void* target, float baseDmg, int boneId);
static float hook_BulletDamage(void* bulletComp, void* target, float baseDmg, int boneId) {
    atomic_fetch_add(&g_stat_dmg_calls, 1);
    int   effectiveBone = boneId;
    float effectiveDmg  = baseDmg;
    if (atomic_load(&g_headshot_enabled)) {
        if (boneId != BONE_HEAD) {
            effectiveBone = BONE_HEAD;
            atomic_fetch_add(&g_stat_redirects, 1);
        }
        int mult_x10 = atomic_load(&g_dmg_multiplier_x10);
        if (mult_x10 != 10) effectiveDmg = baseDmg * ((float)mult_x10 / 10.0f);
    }
    return ((BulletDamage_t)orig_BulletDamage)(bulletComp, target, effectiveDmg, effectiveBone);
}

typedef Vec3* (*BoneGetPos_t)(void* charObj, int boneId);
static Vec3* hook_BoneGetPos(void* charObj, int boneId) {
    atomic_fetch_add(&g_stat_bone_queries, 1);
    if (atomic_load(&g_headshot_enabled) && charObj) {
        if (boneId != BONE_HEAD && boneId != BONE_NECK) {
            Vec3* head = ((BoneGetPos_t)orig_BoneGetPos)(charObj, BONE_HEAD);
            ((BoneGetPos_t)orig_BoneGetPos)(charObj, boneId);
            return head;
        }
    }
    return ((BoneGetPos_t)orig_BoneGetPos)(charObj, boneId);
}

// ── B6: entity list hook — feed pointer to esp.cpp ──────────────────────────
typedef void* (*EntityGetList_t)(void* entityMgr);
static void* hook_EntityGetList(void* entityMgr) {
    if (entityMgr) esp_on_entity_list(entityMgr);
    return ((EntityGetList_t)orig_EntityGetList)(entityMgr);
}

// ── B6: view matrix hook — feed camera pointer to esp.cpp ───────────────────
typedef void* (*ViewMatrix_t)(void* camera);
static void* hook_ViewMatrix(void* camera) {
    if (camera) esp_on_camera(camera);
    return ((ViewMatrix_t)orig_ViewMatrix)(camera);
}

// ════════════════════════════════════════════════════════════════════════════
// Dobby install helper
// ════════════════════════════════════════════════════════════════════════════
static bool install_hook(void* target, void* replace, void** orig_out,
                         const char* name, int* installed, int* failed, int bit) {
    if (!target || (uintptr_t)target == 0) {
        LOGI("Hook %s: addr=0 — skipped", name); return false;
    }
    int ret = DobbyHook(target, replace, orig_out);
    if (ret == 0) { LOGI("Hook %s: OK @ %p", name, target); *installed |= bit; return true; }
    LOGE("Hook %s: FAILED dobby=%d @ %p", name, ret, target); *failed |= bit; return false;
}

// ════════════════════════════════════════════════════════════════════════════
// JNI — unchanged signatures from B4/B5
// ════════════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jint JNICALL
Java_com_ffpanel_hook_HookManager_nativeInstallHooks(
        JNIEnv*, jclass,
        jlong addrDamage, jlong addrBoneGetPos,
        jlong addrEntityList, jlong addrViewMatrix, jlong addrW2S)
{
    int installed = 0, failed = 0;
    install_hook((void*)addrDamage,     (void*)hook_BulletDamage,  &orig_BulletDamage,
                 "BulletDamage",  &installed, &failed, HOOK_DAMAGE);
    install_hook((void*)addrBoneGetPos, (void*)hook_BoneGetPos,    &orig_BoneGetPos,
                 "BoneGetPos",    &installed, &failed, HOOK_BONE);
    install_hook((void*)addrEntityList, (void*)hook_EntityGetList,  &orig_EntityGetList,
                 "EntityGetList", &installed, &failed, HOOK_ENTITY);
    install_hook((void*)addrViewMatrix, (void*)hook_ViewMatrix,     &orig_ViewMatrix,
                 "ViewMatrix",    &installed, &failed, HOOK_VIEWMATRIX);
    orig_W2S    = (void*)addrW2S;
    g_installed = installed;
    LOGI("W2S stored: %p", orig_W2S);
    return (jint)((failed << 16) | (installed & 0xFFFF));
}

extern "C" JNIEXPORT void JNICALL
Java_com_ffpanel_hook_HookManager_nativeUnhookAll(JNIEnv*, jclass)
{
    if (g_installed & HOOK_DAMAGE)     DobbyDestroy((void*)orig_BulletDamage);
    if (g_installed & HOOK_BONE)       DobbyDestroy((void*)orig_BoneGetPos);
    if (g_installed & HOOK_ENTITY)     DobbyDestroy((void*)orig_EntityGetList);
    if (g_installed & HOOK_VIEWMATRIX) DobbyDestroy((void*)orig_ViewMatrix);
    g_installed = 0;
    LOGI("All hooks removed");
}

// B5 exports — unchanged
extern "C" JNIEXPORT void JNICALL
Java_com_ffpanel_hook_HeadshotConfig_nativeSetHeadshot(
        JNIEnv*, jclass, jboolean enabled, jint multiplierX10)
{
    atomic_store(&g_headshot_enabled,   enabled ? 1 : 0);
    atomic_store(&g_dmg_multiplier_x10, (int)multiplierX10);
    LOGI("Headshot: enabled=%d mult=%d/10", (int)enabled, (int)multiplierX10);
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_ffpanel_hook_HeadshotConfig_nativeGetStats(JNIEnv*, jclass)
{
    int calls     = atomic_load(&g_stat_dmg_calls);
    int redirects = atomic_load(&g_stat_redirects);
    return (jlong)(((jlong)redirects << 32) | (jlong)(unsigned)calls);
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;
    LOGI("ffcheat.so B6 loaded");
    return JNI_VERSION_1_6;
}
