# patch_osmem.py
# 
# Dobby master (jmpews/Dobby) has no OSMemory conflict.
# os_arch_features.h simply includes platform.h — no duplicate definitions.
# This script is a no-op. It exists only to avoid breaking the build.yml step.
#
print("patch_osmem: clean Dobby — no patch needed")
