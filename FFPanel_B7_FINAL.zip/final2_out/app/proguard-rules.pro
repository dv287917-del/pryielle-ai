-keep class com.ffpanel.** { *; }
-keepclassmembers class * {
    native <methods>;
}
-dontwarn kotlin.**
-keepattributes *Annotation*
