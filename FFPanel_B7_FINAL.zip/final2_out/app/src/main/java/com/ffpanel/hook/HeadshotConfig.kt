package com.ffpanel.hook

import android.util.Log

/**
 * B5 — Headshot config bridge.
 * Passes enable/multiplier state down to native hook and reads counters back.
 */
object HeadshotConfig {

    private const val TAG = "FFPanel_Headshot"

    object Multiplier {
        const val X1_0 = 10
        const val X1_5 = 15
        const val X2_0 = 20
        const val X2_5 = 25
        const val X3_0 = 30

        // Map seekbar 0-4 to multiplier constants
        fun fromSeekProgress(p: Int): Int = when (p) {
            0    -> X1_0
            1    -> X1_5
            2    -> X2_0
            3    -> X2_5
            4    -> X3_0
            else -> X1_0
        }

        fun label(value: Int): String = "x${value / 10}.${value % 10}"
    }

    data class Stats(val calls: Int, val redirects: Int)

    fun set(enabled: Boolean, multiplierX10: Int = Multiplier.X1_0) {
        try {
            nativeSetHeadshot(enabled, multiplierX10)
            Log.d(TAG, "set enabled=$enabled mult=$multiplierX10")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "nativeSetHeadshot: ${e.message}")
        }
    }

    fun stats(): Stats {
        return try {
            val raw       = nativeGetStats()
            val calls     = (raw and 0xFFFFFFFFL).toInt()
            val redirects = ((raw ushr 32) and 0xFFFFFFFFL).toInt()
            Stats(calls, redirects)
        } catch (e: UnsatisfiedLinkError) {
            Stats(0, 0)
        }
    }

    // ── JNI ─────────────────────────────────────────────────────────────────
    @JvmStatic external fun nativeSetHeadshot(enabled: Boolean, multiplierX10: Int)
    @JvmStatic external fun nativeGetStats(): Long
}
