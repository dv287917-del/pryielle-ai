package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

/**
 * B2 — /proc/maps hiding.
 * Uses Shamiko's maps-hide list to suppress ffcheat.so from /proc/<pid>/maps.
 * Shamiko reads /data/adb/shamiko/whitelist and applies hidemap patches.
 */
object MapsHide {
    private const val TAG       = "FFPanel_MapsHide"
    private const val HIDE_LIST = "/data/adb/shamiko/whitelist"
    private const val SO_NAME   = "ffcheat.so"

    fun apply(): Boolean {
        // Append our SO name to shamiko's whitelist
        val r = RootUtils.exec("echo '$SO_NAME' >> $HIDE_LIST")
        val ok = r.exitCode == 0
        Log.d(TAG, "MapsHide: $SO_NAME added=$ok")
        return ok
    }

    fun revert() {
        // Remove our entry — sed in-place
        RootUtils.execRoot("sed -i '/$SO_NAME/d' $HIDE_LIST")
        Log.d(TAG, "MapsHide: $SO_NAME removed")
    }
}
