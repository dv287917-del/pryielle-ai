package com.ffpanel.hook

import android.content.Context
import android.util.Log
import com.ffpanel.RootUtils
import org.json.JSONObject

/**
 * B4 — Offset config loader.
 *
 * Reads /sdcard/FFPanel/offsets.json from the device.
 * Parses the il2cpp block and resolves each offset to an absolute address
 * by finding libil2cpp.so base in /proc/<pid>/maps.
 *
 * offsets.json schema:
 * {
 *   "il2cpp": {
 *     "BulletDamage":             "0x...",
 *     "CharacterBone_GetPos":     "0x...",
 *     "EntityManager_GetList":    "0x...",
 *     "ViewMatrix":               "0x...",
 *     "WorldToScreen":            "0x...",
 *     "LocalPlayer_GetInstance":  "0x...",
 *     "CharacterBone_GetPos":     "0x..."
 *   }
 * }
 */
object OffsetConfig {

    private const val TAG       = "FFPanel_Offsets"
    private const val CFG_PATH  = "/sdcard/FFPanel/offsets.json"
    private const val IL2CPP    = "libil2cpp.so"

    data class Config(
        val base:  Long,
        val addrs: Map<String, Long>
    )

    fun load(context: Context, pid: Int): Config? {
        return try {
            // Read JSON
            val json = RootUtils.execRoot("cat $CFG_PATH")
            if (json.isBlank()) { Log.e(TAG, "offsets.json missing or empty"); return null }

            val root     = JSONObject(json)
            val il2cpp   = root.getJSONObject("il2cpp")

            // Find libil2cpp.so base address
            val base = findBase(pid) ?: run {
                Log.e(TAG, "Cannot find $IL2CPP in maps")
                return null
            }

            // Resolve each key to absolute address
            val addrs = mutableMapOf<String, Long>()
            for (key in il2cpp.keys()) {
                val offset = il2cpp.getString(key).removePrefix("0x").toLongOrNull(16) ?: 0L
                addrs[key] = base + offset
            }

            Log.d(TAG, "Offsets loaded — base=0x${base.toString(16)} keys=${addrs.keys}")
            Config(base, addrs)
        } catch (e: Exception) {
            Log.e(TAG, "load failed: ${e.message}")
            null
        }
    }

    private fun findBase(pid: Int): Long? {
        val maps = RootUtils.execRoot("cat /proc/$pid/maps")
        for (line in maps.lines()) {
            if (!line.contains(IL2CPP)) continue
            // Format: start-end perms offset dev inode pathname
            val start = line.substringBefore('-').trim()
            return start.toLongOrNull(16)
        }
        return null
    }
}
