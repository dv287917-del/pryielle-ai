package com.ffpanel.hook

import android.util.Log

/**
 * B4 — Hook manager.
 * Calls nativeInstallHooks() in ffcheat.so with resolved addresses.
 */
object HookManager {

    private const val TAG = "FFPanel_HookManager"

    const val HOOK_DAMAGE     = 1 shl 0
    const val HOOK_BONE       = 1 shl 1
    const val HOOK_ENTITY     = 1 shl 2
    const val HOOK_VIEWMATRIX = 1 shl 3

    data class Result(val installed: Int, val failed: Int) {
        val allOk get() = failed == 0 && installed != 0
    }

    fun init(config: OffsetConfig.Config): Result {
        val damage     = config.addrs["BulletDamage"]            ?: 0L
        val bone       = config.addrs["CharacterBone_GetPos"]    ?: 0L
        val entityList = config.addrs["EntityManager_GetList"]   ?: 0L
        val viewMatrix = config.addrs["ViewMatrix"]              ?: 0L
        val w2s        = config.addrs["WorldToScreen"]           ?: 0L

        return try {
            val raw = nativeInstallHooks(damage, bone, entityList, viewMatrix, w2s)
            val installed = raw and 0xFFFF
            val failed    = (raw ushr 16) and 0xFFFF
            Log.d(TAG, "Hooks installed=0x${installed.toString(16)} failed=0x${failed.toString(16)}")
            Result(installed, failed)
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "nativeInstallHooks link error: ${e.message}")
            Result(0, 0xF)
        }
    }

    fun unhookAll() {
        try { nativeUnhookAll() }
        catch (e: UnsatisfiedLinkError) { Log.e(TAG, "nativeUnhookAll: ${e.message}") }
    }

    // ── JNI ─────────────────────────────────────────────────────────────────
    @JvmStatic external fun nativeInstallHooks(
        addrDamage:    Long,
        addrBoneGetPos: Long,
        addrEntityList: Long,
        addrViewMatrix: Long,
        addrW2S:       Long
    ): Int

    @JvmStatic external fun nativeUnhookAll()
}
