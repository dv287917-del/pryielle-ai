package com.ffpanel.inject

import android.util.Log
import com.ffpanel.RootUtils

/**
 * B3 — ptrace + memfd SO injector.
 *
 * Strategy:
 *   1. ptrace-attach to target process
 *   2. memfd_create in target → write SO bytes → pass fd via /proc/<pid>/fd
 *   3. Call dlopen("/proc/<pid>/fd/<memfd>", RTLD_NOW) in target address space
 *   4. ptrace-detach
 *
 * We shell out to a prebuilt root binary (`ffinjector`) bundled as an asset
 * and extracted to /data/local/tmp. This keeps all ptrace logic in C,
 * avoiding the complexity of doing raw ptrace from Kotlin/JNI.
 */
object SoInjector {
    private const val TAG = "FFPanel_SoInjector"

    data class Result(val success: Boolean, val error: String = "")

    /**
     * @param pid     PID of the target process (Free Fire)
     * @param soPath  Absolute path to the SO to inject (world-readable)
     */
    fun inject(pid: Int, soPath: String): Result {
        Log.d(TAG, "Injecting $soPath into pid=$pid")

        // Run the injector binary with root
        val r = RootUtils.exec("ffinjector $pid $soPath")
        return if (r.exitCode == 0) {
            Log.d(TAG, "Inject OK: ${r.output}")
            Result(true)
        } else {
            Log.e(TAG, "Inject FAILED (exit=${r.exitCode}): ${r.output}")
            Result(false, r.output.ifEmpty { "exit=${r.exitCode}" })
        }
    }
}
