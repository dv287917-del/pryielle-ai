package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

/**
 * B2 — Process name spoofing.
 * Writes an innocuous name into /proc/self/comm to avoid name-based detection.
 */
object ProcessSpoof {
    private const val TAG    = "FFPanel_ProcSpoof"
    private const val SPOOF  = "android.process"
    private const val COMM   = "/proc/self/comm"

    private var original: String = ""

    fun apply(): Boolean {
        original = RootUtils.execRoot("cat $COMM").trim()
        val r    = RootUtils.exec("echo '$SPOOF' > $COMM")
        val ok   = r.exitCode == 0
        Log.d(TAG, "ProcessSpoof: $original → $SPOOF ok=$ok")
        return ok
    }

    fun revert() {
        if (original.isNotEmpty()) {
            RootUtils.execRoot("echo '$original' > $COMM")
        }
    }
}
