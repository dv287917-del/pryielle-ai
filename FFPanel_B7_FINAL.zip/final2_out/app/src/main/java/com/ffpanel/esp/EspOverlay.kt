package com.ffpanel.esp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager

/**
 * B6 — ESP Overlay
 *
 * TYPE_APPLICATION_OVERLAY window drawn above all apps.
 * Transparent background, draws enemy boxes + distance labels via Canvas.
 * Polls EspRenderer at ~30 fps on a background HandlerThread.
 *
 * Requires SYSTEM_ALERT_WINDOW permission (request before calling show()).
 */
class EspOverlay(private val context: Context) {

    private val TAG = "FFPanel_EspOverlay"

    // ── Paints ───────────────────────────────────────────────────────────────
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color  = Color.RED
        style  = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color  = Color.RED
        style  = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val headDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW
        style = Paint.Style.FILL
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color     = Color.WHITE
        textSize  = 26f
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = Color.argb(120, 255, 0, 0)
        strokeWidth = 1f
    }

    // ── WindowManager layout ─────────────────────────────────────────────────
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val layoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private var surfaceView: EspSurfaceView? = null
    private var drawThread: HandlerThread?   = null
    private var drawHandler: Handler?        = null

    @Volatile private var running = false

    // ── Lifecycle ────────────────────────────────────────────────────────────

    fun show() {
        if (surfaceView != null) return
        val sv = EspSurfaceView(context, this)
        surfaceView = sv
        wm.addView(sv, layoutParams)
        Log.d(TAG, "Overlay added")
    }

    fun hide() {
        stopDraw()
        surfaceView?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        surfaceView = null
        Log.d(TAG, "Overlay removed")
    }

    fun setEspEnabled(enabled: Boolean) {
        if (enabled) startDraw() else stopDraw()
    }

    // ── Draw loop ────────────────────────────────────────────────────────────

    private fun startDraw() {
        if (running) return
        running = true
        drawThread = HandlerThread("esp_draw").also { it.start() }
        drawHandler = Handler(drawThread!!.looper)
        scheduleNext()
    }

    private fun stopDraw() {
        running = false
        drawHandler?.removeCallbacksAndMessages(null)
        drawThread?.quitSafely()
        drawThread = null
        drawHandler = null
        // Clear canvas
        surfaceView?.clearCanvas()
    }

    private fun scheduleNext() {
        if (!running) return
        drawHandler?.postDelayed({
            tick()
            scheduleNext()
        }, 33L)   // ~30 fps
    }

    internal fun tick() {
        val sv = surfaceView ?: return
        val holder = sv.holder
        if (!holder.surface.isValid) return

        val frames = EspRenderer.getFrames()
        val canvas = holder.lockCanvas() ?: return
        try {
            canvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR)
            if (frames.isNotEmpty()) drawFrames(canvas, frames)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    // ── Draw routines ────────────────────────────────────────────────────────

    private fun drawFrames(canvas: Canvas, frames: List<EspRenderer.EspFrame>) {
        for (f in frames) {
            drawBox(canvas, f)
            drawHeadDot(canvas, f)
            drawDistLabel(canvas, f)
            drawSnapLine(canvas, f)
        }
    }

    /**
     * Corner-style ESP box — 4 corners, each drawn as two short lines.
     * Less noisy than a full rectangle, standard in most cheats.
     */
    private fun drawBox(canvas: Canvas, f: EspRenderer.EspFrame) {
        val left   = f.headX - f.boxW * 0.5f
        val right  = f.headX + f.boxW * 0.5f
        val top    = f.headY
        val bottom = f.footY
        val cw     = f.boxW * 0.25f   // corner segment length
        val ch     = f.boxH * 0.20f

        // Top-left
        canvas.drawLine(left,  top,    left + cw, top,    cornerPaint)
        canvas.drawLine(left,  top,    left,  top + ch,   cornerPaint)
        // Top-right
        canvas.drawLine(right, top,    right - cw, top,   cornerPaint)
        canvas.drawLine(right, top,    right, top + ch,   cornerPaint)
        // Bottom-left
        canvas.drawLine(left,  bottom, left + cw, bottom, cornerPaint)
        canvas.drawLine(left,  bottom, left,  bottom - ch,cornerPaint)
        // Bottom-right
        canvas.drawLine(right, bottom, right - cw, bottom,cornerPaint)
        canvas.drawLine(right, bottom, right, bottom - ch,cornerPaint)
    }

    private fun drawHeadDot(canvas: Canvas, f: EspRenderer.EspFrame) {
        canvas.drawCircle(f.headX, f.headY, 4f, headDotPaint)
    }

    private fun drawDistLabel(canvas: Canvas, f: EspRenderer.EspFrame) {
        val label = if (f.dist > 0f) "%.0fm".format(f.dist) else "?"
        canvas.drawText(label, f.headX - f.boxW * 0.5f, f.footY + 20f, textPaint)
    }

    /** Snap line from bottom-centre of screen to foot midpoint */
    private fun drawSnapLine(canvas: Canvas, f: EspRenderer.EspFrame) {
        val screenCx = surfaceView?.width?.toFloat()?.div(2f) ?: return
        val screenH  = surfaceView?.height?.toFloat() ?: return
        canvas.drawLine(screenCx, screenH, f.footX, f.footY, linePaint)
    }

    // ── SurfaceView ──────────────────────────────────────────────────────────

    class EspSurfaceView(context: Context, private val overlay: EspOverlay)
        : SurfaceView(context), SurfaceHolder.Callback {

        init {
            setZOrderMediaOverlay(true)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            holder.addCallback(this)
        }

        override fun surfaceCreated(holder: SurfaceHolder) {
            // Init renderer with actual screen dimensions
            val lp = overlay.wm.currentWindowMetrics.bounds
            EspRenderer.init(
                screenW          = lp.width().toFloat(),
                screenH          = lp.height().toFloat(),
                localPlayerAddr  = 0L   // set via EspRenderer.nativeSetLocalPlayerAddr() after offset load
            )
            overlay.startDraw()
        }

        override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) {}
        override fun surfaceDestroyed(holder: SurfaceHolder) { overlay.stopDraw() }

        fun clearCanvas() {
            val canvas = holder.lockCanvas() ?: return
            try { canvas.drawColor(Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR) }
            finally { holder.unlockCanvasAndPost(canvas) }
        }
    }
}
