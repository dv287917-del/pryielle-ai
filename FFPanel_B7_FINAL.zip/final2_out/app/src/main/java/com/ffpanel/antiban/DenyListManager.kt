package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

object DenyListManager {
    private const val TAG = "FFPanel_DenyList"

    fun addPackage(pkg: String): Boolean {
        // Add target package to Magisk DenyList so root is hidden from it
        val r = RootUtils.exec("magisk --denylist add $pkg")
        val ok = r.exitCode == 0
        Log.d(TAG, "DenyList add $pkg: $ok")
        return ok
    }

    fun removePackage(pkg: String) {
        RootUtils.execRoot("magisk --denylist rm $pkg")
        Log.d(TAG, "DenyList remove $pkg")
    }
}
