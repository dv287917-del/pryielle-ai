package com.ffpanel

import android.util.Log
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

/**
 * B1 — Root shell utilities.
 * Runs commands via `su` and returns stdout as a trimmed string.
 */
object RootUtils {

    private const val TAG = "FFPanel_Root"

    data class Result(val output: String, val exitCode: Int)

    fun execRoot(cmd: String): String = exec(cmd).output

    fun exec(cmd: String): Result {
        return try {
            val process = Runtime.getRuntime().exec("su")
            val dos = DataOutputStream(process.outputStream)
            dos.writeBytes("$cmd\n")
            dos.writeBytes("exit\n")
            dos.flush()
            dos.close()

            val reader  = BufferedReader(InputStreamReader(process.inputStream))
            val output  = reader.readLines().joinToString("\n").trim()
            val exit    = process.waitFor()
            Log.d(TAG, "[$exit] $cmd → $output")
            Result(output, exit)
        } catch (e: Exception) {
            Log.e(TAG, "exec failed: ${e.message}")
            Result("", -1)
        }
    }

    fun isRooted(): Boolean {
        val r = exec("id")
        return r.exitCode == 0 && r.output.contains("uid=0")
    }
}
