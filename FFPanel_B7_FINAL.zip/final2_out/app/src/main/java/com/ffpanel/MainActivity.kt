package com.ffpanel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.ffpanel.databinding.ActivityMainBinding
import com.ffpanel.hook.HeadshotConfig

/**
 * B7 — Main panel activity.
 *
 * Controls:
 *   - Inject / Eject buttons
 *   - Headshot toggle + multiplier seekbar
 *   - ESP toggle
 *   - Safe Mode toggle
 *   - Live status + stats display
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var injected = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                "com.ffpanel.INJECT_STATUS" -> {
                    val s = intent.getStringExtra("status") ?: return
                    updateStatus(s)
                }
                "com.ffpanel.STATS_UPDATE" -> {
                    val r = intent.getIntExtra("redirects", 0)
                    val c = intent.getIntExtra("calls",     0)
                    binding.tvStats.text = "Redirects: $r / Calls: $c"
                }
            }
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupControls()
        registerReceivers()
    }

    override fun onDestroy() {
        unregisterReceiver(statusReceiver)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        // After returning from overlay permission screen
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
        }
    }

    // ── Setup ────────────────────────────────────────────────────────────────

    private fun setupControls() {
        // Multiplier seekbar
        binding.seekMultiplier.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val mult = HeadshotConfig.Multiplier.fromSeekProgress(progress)
                binding.tvMultiplierLabel.text = HeadshotConfig.Multiplier.label(mult)
                if (injected && binding.switchHeadshot.isChecked) {
                    sendServiceAction("headshot_toggle") {
                        putExtra("enabled",        true)
                        putExtra("multiplier_x10", mult)
                    }
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar)  {}
        })

        // Headshot switch
        binding.switchHeadshot.setOnCheckedChangeListener { _, on ->
            if (injected) {
                val mult = HeadshotConfig.Multiplier.fromSeekProgress(binding.seekMultiplier.progress)
                sendServiceAction("headshot_toggle") {
                    putExtra("enabled",        on)
                    putExtra("multiplier_x10", mult)
                }
            }
        }

        // ESP switch
        binding.switchEsp.setOnCheckedChangeListener { _, on ->
            if (injected) {
                sendServiceAction("esp_toggle") { putExtra("enabled", on) }
            }
        }

        // Safe Mode switch (B7)
        binding.switchSafeMode.setOnCheckedChangeListener { _, on ->
            if (injected) {
                sendServiceAction("safe_mode") { putExtra("enabled", on) }
            }
        }

        // Inject
        binding.btnInject.setOnClickListener {
            if (!checkOverlayPermission()) return@setOnClickListener

            val mult = HeadshotConfig.Multiplier.fromSeekProgress(binding.seekMultiplier.progress)
            sendServiceAction("inject") {
                putExtra("headshot_enabled", binding.switchHeadshot.isChecked)
                putExtra("headshot_mult",    mult)
                putExtra("esp_enabled",      binding.switchEsp.isChecked)
            }
            setInjected(true)
        }

        // Eject
        binding.btnEject.setOnClickListener {
            sendServiceAction("eject")
            setInjected(false)
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction("com.ffpanel.INJECT_STATUS")
            addAction("com.ffpanel.STATS_UPDATE")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(statusReceiver, filter)
        }
    }

    // ── State ────────────────────────────────────────────────────────────────

    private fun setInjected(on: Boolean) {
        injected = on
        binding.btnInject.isEnabled = !on
        binding.btnEject.isEnabled  =  on
    }

    private fun updateStatus(s: String) {
        val label = when {
            s.startsWith("antiban")   -> "Anti-ban: ${s.removePrefix("antiban_")}"
            s == "not_found"          -> "⚠ FF not running"
            s.startsWith("inject")    -> "Inject: ${s.removePrefix("inject_")}"
            s.startsWith("offsets")   -> "Offsets: ${s.removePrefix("offsets_")}"
            s.startsWith("hooks")     -> "Hooks: ${s.removePrefix("hooks_")}"
            s.startsWith("headshot")  -> "Headshot: ${s.removePrefix("headshot_")}"
            s.startsWith("esp")       -> "ESP: ${s.removePrefix("esp_")}"
            s.startsWith("safe")      -> "Safe mode: ${s.removePrefix("safe_")}"
            s == "ready"              -> "✓ Ready"
            s == "ejected"            -> "Ejected"
            else                      -> s
        }
        binding.tvStatus.text = "Status: $label"
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun checkOverlayPermission(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        return false
    }

    private fun sendServiceAction(action: String, extras: Intent.() -> Unit = {}) {
        val i = Intent(this, InjectorService::class.java)
        i.putExtra("action", action)
        i.apply(extras)
        startForegroundService(i)
    }
}
