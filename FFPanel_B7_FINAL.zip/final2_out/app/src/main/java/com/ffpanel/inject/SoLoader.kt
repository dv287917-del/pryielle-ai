package com.ffpanel.inject

import android.content.Context
import android.util.Log
import com.ffpanel.RootUtils
import java.io.File

/**
 * B3 — SO loader.
 * Copies ffcheat.so from APK assets to a tmp path, then hands off to SoInjector.
 */
object SoLoader {
    private const val TAG    = "FFPanel_SoLoader"
    private const val SO_NAME = "libffcheat.so"

    data class Result(val success: Boolean, val error: String = "")

    fun load(context: Context, pid: Int): Result {
        return try {
            // Extract SO from native libs directory
            val nativeDir = context.applicationInfo.nativeLibraryDir
            val soFile    = File("$nativeDir/$SO_NAME")

            if (!soFile.exists()) {
                Log.e(TAG, "SO not found: ${soFile.absolutePath}")
                return Result(false, "so_missing")
            }

            // Copy to world-readable tmp path
            val tmpPath = "/data/local/tmp/ffcheat_${System.currentTimeMillis()}.so"
            val cp      = RootUtils.exec("cp ${soFile.absolutePath} $tmpPath && chmod 755 $tmpPath")
            if (cp.exitCode != 0) return Result(false, "copy_failed")

            // Inject into target process
            val injResult = SoInjector.inject(pid, tmpPath)

            // Clean up tmp
            RootUtils.execRoot("rm -f $tmpPath")

            injResult
        } catch (e: Exception) {
            Log.e(TAG, "load failed: ${e.message}")
            Result(false, e.message ?: "unknown")
        }
    }
}
