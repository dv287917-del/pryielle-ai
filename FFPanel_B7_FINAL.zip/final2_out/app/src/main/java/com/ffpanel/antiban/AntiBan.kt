package com.ffpanel.antiban

import android.util.Log

/**
 * B2 — Anti-ban coordinator.
 * Applies all anti-detection layers before injection.
 */
object AntiBan {

    private const val TAG = "FFPanel_AntiBan"

    data class Result(
        val shamiko:   Boolean,
        val denyList:  Boolean,
        val procSpoof: Boolean,
        val mapsHide:  Boolean
    ) {
        val allOk get() = shamiko && denyList && procSpoof && mapsHide
    }

    fun apply(targetPkg: String): Result {
        Log.d(TAG, "Applying anti-ban for $targetPkg")
        val sh = ShamikoManager.enable()
        val dl = DenyListManager.addPackage(targetPkg)
        val ps = ProcessSpoof.apply()
        val mh = MapsHide.apply()
        val r  = Result(sh, dl, ps, mh)
        Log.d(TAG, "Anti-ban result: $r")
        return r
    }

    fun revert(targetPkg: String) {
        DenyListManager.removePackage(targetPkg)
        ProcessSpoof.revert()
        MapsHide.revert()
        Log.d(TAG, "Anti-ban reverted")
    }
}
