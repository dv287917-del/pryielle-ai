package com.ffpanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import com.ffpanel.antiban.AntiBan
import com.ffpanel.esp.EspOverlay
import com.ffpanel.esp.EspRenderer
import com.ffpanel.hook.HeadshotConfig
import com.ffpanel.hook.HookManager
import com.ffpanel.hook.OffsetConfig
import com.ffpanel.inject.SoLoader

/**
 * B7 — Foreground injector service with safe-mode toggle.
 *
 * Actions (via Intent extra "action"):
 *   inject           — full inject pipeline
 *   eject            — unhook + remove overlay
 *   headshot_toggle  — enable/disable headshot (extras: enabled, multiplier_x10)
 *   esp_toggle       — show/hide ESP overlay (extra: enabled)
 *   safe_mode        — pause all hooks without ejecting (extra: enabled)
 */
class InjectorService : Service() {

    private val TAG        = "FFPanel_Injector"
    private val TARGET_PKG = "com.dts.freefireth"
    private val CH_ID      = "ffpanel_fg"

    private var espOverlay:   EspOverlay? = null
    private var safeModeOn:   Boolean     = false
    private var statsHandler: Handler?    = null
    private val STATS_INTERVAL = 2_000L

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, buildNotification("FFPanel running"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.getStringExtra("action") ?: "inject") {
            "inject"          -> doInject(intent)
            "eject"           -> doEject()
            "headshot_toggle" -> {
                val on   = intent?.getBooleanExtra("enabled", true) ?: true
                val mult = intent?.getIntExtra("multiplier_x10", HeadshotConfig.Multiplier.X1_0)
                               ?: HeadshotConfig.Multiplier.X1_0
                HeadshotConfig.set(on, mult)
                broadcastStatus("headshot_${if (on) "on" else "off"}")
            }
            "esp_toggle"      -> {
                val on = intent?.getBooleanExtra("enabled", true) ?: true
                espOverlay?.setEspEnabled(on)
                broadcastStatus("esp_${if (on) "on" else "off"}")
            }
            "safe_mode"       -> {
                val on = intent?.getBooleanExtra("enabled", false) ?: false
                applySafeMode(on)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopStatsPoller()
        espOverlay?.hide()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Inject pipeline ──────────────────────────────────────────────────────

    private fun doInject(intent: Intent?) {
        // B2 — anti-ban
        val banResult = AntiBan.apply(TARGET_PKG)
        broadcastStatus("antiban_${if (banResult.allOk) "ok" else "partial"}")

        val pid = findTargetPid()
        if (pid <= 0) { broadcastStatus("not_found"); return }
        broadcastStatus("injecting", pid)

        // B3 — SO inject
        val loadResult = SoLoader.load(this, pid)
        if (!loadResult.success) {
            broadcastStatus("inject_fail", pid, error = loadResult.error); return
        }
        broadcastStatus("inject_ok", pid)

        // B4 — offsets
        val config = OffsetConfig.load(this, pid)
        if (config == null) { broadcastStatus("offsets_fail", pid); return }
        broadcastStatus("offsets_ok", pid)

        // B4 — hooks
        val hookResult = HookManager.init(config)
        broadcastStatus(
            if (hookResult.allOk) "hooks_ok" else "hooks_partial",
            pid, extra = hookResult.installed
        )

        // B5 — headshot
        val hsEnabled = intent?.getBooleanExtra("headshot_enabled", true) ?: true
        val hsMult    = intent?.getIntExtra("headshot_mult", HeadshotConfig.Multiplier.X1_0)
                            ?: HeadshotConfig.Multiplier.X1_0
        if (hookResult.installed and HookManager.HOOK_DAMAGE != 0 &&
            hookResult.installed and HookManager.HOOK_BONE   != 0) {
            HeadshotConfig.set(hsEnabled, hsMult)
            broadcastStatus("headshot_${if (hsEnabled) "on" else "off"}")
        }

        // B6 — ESP overlay
        val lpAddr     = config.addrs["LocalPlayer_GetInstance"] ?: 0L
        val espEnabled = intent?.getBooleanExtra("esp_enabled", true) ?: true

        Handler(Looper.getMainLooper()).post {
            val overlay = EspOverlay(applicationContext)
            espOverlay  = overlay
            overlay.show()
            if (lpAddr != 0L) EspRenderer.nativeSetLocalPlayerAddr(lpAddr)
            overlay.setEspEnabled(espEnabled)
            broadcastStatus("esp_${if (espEnabled) "on" else "off"}")
        }

        // B7 — start stats polling
        startStatsPoller()

        broadcastStatus("ready", pid)
    }

    private fun doEject() {
        stopStatsPoller()
        espOverlay?.hide()
        espOverlay = null
        HeadshotConfig.set(false)
        HookManager.unhookAll()
        AntiBan.revert(TARGET_PKG)
        broadcastStatus("ejected")
        stopSelf()
    }

    // ── B7: Safe mode ────────────────────────────────────────────────────────

    /**
     * Safe mode: disable headshot + ESP when AC scanner might be active,
     * without full eject. Re-enable when toggled off.
     */
    private fun applySafeMode(on: Boolean) {
        safeModeOn = on
        if (on) {
            HeadshotConfig.set(false)
            espOverlay?.setEspEnabled(false)
            broadcastStatus("safe_on")
        } else {
            broadcastStatus("safe_off")
        }
        Log.d(TAG, "Safe mode: $on")
    }

    // ── B7: Stats poller ─────────────────────────────────────────────────────

    private fun startStatsPoller() {
        val h = Handler(Looper.getMainLooper())
        statsHandler = h
        val r = object : Runnable {
            override fun run() {
                val s = HeadshotConfig.stats()
                broadcastStats(s.redirects, s.calls)
                h.postDelayed(this, STATS_INTERVAL)
            }
        }
        h.postDelayed(r, STATS_INTERVAL)
    }

    private fun stopStatsPoller() {
        statsHandler?.removeCallbacksAndMessages(null)
        statsHandler = null
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun findTargetPid(): Int {
        val result = RootUtils.execRoot("pidof $TARGET_PKG")
        return result.trim().split("\\s+".toRegex()).firstOrNull()?.toIntOrNull() ?: -1
    }

    private fun broadcastStatus(
        status: String, pid: Int = -1,
        extra: Int = 0, error: String = ""
    ) {
        val i = Intent("com.ffpanel.INJECT_STATUS")
        i.putExtra("status", status)
        if (pid > 0)            i.putExtra("pid",   pid)
        if (extra != 0)         i.putExtra("extra", extra)
        if (error.isNotEmpty()) i.putExtra("error", error)
        sendBroadcast(i)
    }

    private fun broadcastStats(redirects: Int, calls: Int) {
        val i = Intent("com.ffpanel.STATS_UPDATE")
        i.putExtra("redirects", redirects)
        i.putExtra("calls",     calls)
        sendBroadcast(i)
    }

    // ── Notification ─────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CH_ID, "FFPanel", NotificationManager.IMPORTANCE_LOW)
        ch.description = "FFPanel foreground service"
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification =
        Notification.Builder(this, CH_ID)
            .setContentTitle("FFPanel")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
}
