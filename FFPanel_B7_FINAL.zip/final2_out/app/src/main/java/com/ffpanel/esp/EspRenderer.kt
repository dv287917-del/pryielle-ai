package com.ffpanel.esp

import android.util.Log

/**
 * B6 — ESP Renderer (JNI bridge side)
 *
 * Calls nativeGetEspFrames() to pull entity screen positions from native,
 * parses the flat float buffer into EspFrame objects for EspOverlay to draw.
 */
object EspRenderer {

    private const val TAG         = "FFPanel_ESP"
    const val MAX_ENTITIES        = 32
    private const val FLOATS_PER  = 8

    private val frameBuffer = FloatArray(MAX_ENTITIES * FLOATS_PER)

    data class EspFrame(
        val headX: Float, val headY: Float,
        val footX: Float, val footY: Float,
        val boxW:  Float, val boxH:  Float,
        val dist:  Float
    )

    fun init(screenW: Float, screenH: Float, localPlayerAddr: Long) {
        try {
            nativeSetScreenSize(screenW, screenH)
            if (localPlayerAddr != 0L) nativeSetLocalPlayerAddr(localPlayerAddr)
            Log.d(TAG, "EspRenderer init: ${screenW}×${screenH} lp=0x${localPlayerAddr.toString(16)}")
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "init link error: ${e.message}")
        }
    }

    /**
     * Pull current frame data from native.
     * Returns list of visible enemy frames. Empty if ESP not ready.
     */
    fun getFrames(): List<EspFrame> {
        val count = try {
            nativeGetEspFrames(frameBuffer, MAX_ENTITIES)
        } catch (e: UnsatisfiedLinkError) {
            return emptyList()
        }
        if (count <= 0) return emptyList()

        val result = ArrayList<EspFrame>(count)
        for (i in 0 until count) {
            val b = i * FLOATS_PER
            if (frameBuffer[b + 7] == 0f) continue   // valid flag
            result.add(EspFrame(
                headX = frameBuffer[b + 0], headY = frameBuffer[b + 1],
                footX = frameBuffer[b + 2], footY = frameBuffer[b + 3],
                boxW  = frameBuffer[b + 4], boxH  = frameBuffer[b + 5],
                dist  = frameBuffer[b + 6]
            ))
        }
        return result
    }

    // ── JNI ─────────────────────────────────────────────────────────────────
    @JvmStatic external fun nativeSetScreenSize(w: Float, h: Float)
    @JvmStatic external fun nativeSetLocalPlayerAddr(addr: Long)
    @JvmStatic external fun nativeGetEspFrames(out: FloatArray, max: Int): Int
}
