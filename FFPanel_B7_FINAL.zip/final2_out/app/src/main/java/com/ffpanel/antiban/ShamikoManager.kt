package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

object ShamikoManager {
    private const val TAG = "FFPanel_Shamiko"

    fun enable(): Boolean {
        // Shamiko is controlled via Zygisk module toggle in Magisk
        // We verify it's active by checking its prop
        val prop = RootUtils.execRoot("getprop ro.shamiko.active").trim()
        val ok   = prop == "1" || prop.equals("true", ignoreCase = true)
        Log.d(TAG, "Shamiko active: $ok (prop=$prop)")
        return ok
    }
}
