# Pryielle MSG v2.13.0 — Mega Update source changes

## Changes made in this source revision

1. **Home announcement voice message:** Admin → Banner accepts an optional HTTPS audio URL. When the banner is enabled, the Home screen shows a native audio player with `preload="none"` so it does not download audio until the user chooses to play it. Existing text-only banners remain compatible.
2. **IP lookup reliability:** the public-IP helper now checks HTTP status, validates the returned IP characters, avoids cache reuse at the fetch layer, uses a shorter timeout, and always clears the timeout when a provider fails or succeeds.
3. **Firebase setup:** the supplied `google-services.json` is installed as `config/google-services.json` for the existing build scripts.
4. **Documentation:** added security limitations and update notes to `README.md`.

## Existing features retained (not duplicated)

The source already contains signup approval/rejection and appeals, admin update publishing, moderation alerts and message edit/delete audit functions, device/IP ban signals, followers/custom counts, GIF caching, Lite/performance mode, themes, notes, profile editing, and emergency alarm support.

## Important limits

This is a source-level change, not a claim that an APK has been built or installed. Client-side anti-cheat can be bypassed; security-critical authorization must be enforced by Firestore rules or trusted backend code. IP/device/VPN checks cannot guarantee that a banned person can never return. The admin chat/audit capability is sensitive and should be clearly disclosed and limited to legitimate moderation.
