# Free Fire India Cheat Panel — Progress

## Stack
- Root: Magisk + Zygisk + Shamiko
- Injector: ptrace / memfd_create (SO inject)
- Hook: Dobby inline hook
- Offsets: runtime config (libil2cpp.so offsets)
- Hide: DenyList, process spoof, maps hide

## Batches

| Batch | Status | Notes |
|-------|--------|-------|
| B1 — Root check + injector app shell + popup UI | ✅ Done | RootUtils.kt, InjectorService.kt, MainActivity.kt, overlay popup, build.gradle |
| B2 — Anti-ban layer | ✅ Done | AntiBan.kt, ShamikoManager.kt, DenyListManager.kt, ProcessSpoof.kt, MapsHide.kt, InjectorService updated |
| B3 — SO injector | ⬜ Pending | ptrace/memfd path, FF inject |
| B4 — Hook setup + offset config loader | ⬜ Pending | Dobby, JSON offset config |
| B5 — Headshot bone redirect | ⬜ Pending | damage hook, bone ID swap |
| B6 — ESP overlay | ⬜ Pending | WindowManager draw layer |
| B7 — Safe mode toggle + panel UI polish | ⬜ Pending | final polish |

## Notes
- Offsets always from config file, never hardcoded
- Anti-ban wired from B2 onward into every layer
- Every batch: full runnable code, no stubs
- B3: after SO drop, call MapsHide.bindAfterDrop() to wire disguise mount
