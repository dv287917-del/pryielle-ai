# FFPanel — B2 Anti-Ban Layer

## Files Added / Changed

| File | Action |
|------|--------|
| `antiban/AntiBan.kt` | Master controller — apply() / revert() |
| `antiban/ShamikoManager.kt` | Shamiko whitelist management |
| `antiban/DenyListManager.kt` | Magisk DenyList add/remove/enforce |
| `antiban/ProcessSpoof.kt` | Process name + cmdline + PM hide |
| `antiban/MapsHide.kt` | Magisk module + bind-mount SO disguise |
| `InjectorService.kt` | Updated — AntiBan.apply() before inject |
| `RootUtils.kt` | Unchanged from B1 — included for completeness |

## Merge Into B1

Copy `antiban/` package into B1 project's `java/com/ffpanel/`.
Replace B1's `InjectorService.kt` with this one.

## How It Works

```
Inject trigger
    └── AntiBan.apply()
            ├── ShamikoManager.ensure()     → whitelist own pkg, verify Shamiko active
            ├── DenyListManager.addPackage() → FF goes on DenyList, can't see Magisk
            ├── ProcessSpoof.apply()         → rename comm, hide pm entry, spoof cmdline
            └── MapsHide.apply()             → Magisk module + bind-mount disguise path
    └── InjectorService finds FF PID
    └── [B3 fires ptrace inject here]
```

## Shamiko Note
Shamiko must be installed as a Zygisk module in Magisk.
If absent, DenyList + spoof still run — just no Zygisk-level hiding.

## MapsHide Note
Bind-mount for the .so fires in `MapsHide.bindAfterDrop()` — B3 calls this
after dropping `ffcheat.so` to `/data/local/tmp/`.
