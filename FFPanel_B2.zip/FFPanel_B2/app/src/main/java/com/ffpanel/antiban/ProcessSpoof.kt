package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

/**
 * ProcessSpoof
 *
 * Hides our injector process from FF's process scanner.
 * FF scans /proc for suspicious process names and parent PIDs.
 *
 * Techniques:
 *  1. Rename our process via prctl(PR_SET_NAME) — done in native (B3 wires native call).
 *     Here we do it via /proc/self/comm through root shell as the shell-level equivalent.
 *  2. Remap our process entry in /proc to look like a system process.
 *  3. Hide our package from pm list (mount-based overlay trick).
 *
 * The full prctl call is in the native .so (B3). This class does the
 * shell-accessible parts that work before native inject.
 */
object ProcessSpoof {

    private const val TAG = "FFPanel_Spoof"

    // Spoof name — looks like a system daemon
    private const val SPOOF_NAME = "com.android.vending"
    private const val SPOOF_COMM = "GmsCore"

    private var originalComm: String = ""
    private var applied = false

    fun apply(): Boolean {
        return try {
            // 1. Read original comm
            originalComm = RootUtils.execRoot("cat /proc/self/comm").trim()

            // 2. Write spoofed comm (kernel allows this for own process via root)
            RootUtils.execRoot("echo '$SPOOF_COMM' > /proc/self/comm")

            // 3. Mount-overlay hide our package entry from FF's pm scan
            hidePmEntry()

            // 4. Clear cmdline visibility (rename in /proc/self/cmdline via bind mount)
            spoofCmdline()

            applied = true
            Log.d(TAG, "ProcessSpoof applied — comm=$SPOOF_COMM")
            true
        } catch (e: Exception) {
            Log.e(TAG, "ProcessSpoof failed: ${e.message}")
            false
        }
    }

    fun revert() {
        if (!applied) return
        try {
            if (originalComm.isNotEmpty()) {
                RootUtils.execRoot("echo '$originalComm' > /proc/self/comm")
            }
            revertPmHide()
            revertCmdline()
            applied = false
            Log.d(TAG, "ProcessSpoof reverted")
        } catch (e: Exception) {
            Log.e(TAG, "ProcessSpoof revert failed: ${e.message}")
        }
    }

    // Hide our APK path from /data/app listing via bind-mount over a dummy dir
    private fun hidePmEntry() {
        val ourApkDir = RootUtils.execRoot(
            "pm path com.ffpanel | sed 's/package://' | xargs dirname"
        ).trim()

        if (ourApkDir.isEmpty()) return

        // Create a tmpfs mount point that looks empty
        val tmpDir = "/data/local/tmp/ff_pm_hide"
        RootUtils.execRoot("mkdir -p $tmpDir")
        RootUtils.execRoot("mount --bind $tmpDir $ourApkDir")
        Log.d(TAG, "PM hide: bind-mounted $ourApkDir → $tmpDir")
    }

    private fun revertPmHide() {
        val ourApkDir = RootUtils.execRoot(
            "pm path com.ffpanel 2>/dev/null | sed 's/package://' | xargs dirname"
        ).trim()
        if (ourApkDir.isNotEmpty()) {
            RootUtils.execRoot("umount $ourApkDir 2>/dev/null")
        }
    }

    // Spoof /proc/self/cmdline via tmpfs bind-mount over a temp file
    private fun spoofCmdline() {
        val tmpCmdline = "/data/local/tmp/ff_cmdline_spoof"
        // Write the spoofed cmdline bytes (null-terminated, Android format)
        RootUtils.execRoot("printf '$SPOOF_NAME\\x00' > $tmpCmdline")
        RootUtils.execRoot("mount --bind $tmpCmdline /proc/self/cmdline 2>/dev/null || true")
    }

    private fun revertCmdline() {
        RootUtils.execRoot("umount /proc/self/cmdline 2>/dev/null || true")
    }
}
