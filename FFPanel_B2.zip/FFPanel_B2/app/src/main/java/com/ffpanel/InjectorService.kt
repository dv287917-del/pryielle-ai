package com.ffpanel

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.ffpanel.antiban.AntiBan

class InjectorService : Service() {

    private val TAG = "FFPanel_Injector"
    private val TARGET_PKG = "com.dts.freefireth"

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "InjectorService started")

        val action = intent?.getStringExtra("action") ?: "inject"

        when (action) {
            "inject" -> {
                // ── B2: Anti-ban FIRST, always ──────────────────────────────
                val banResult = AntiBan.apply(TARGET_PKG)
                Log.d(TAG, "AntiBan: $banResult")

                broadcastAntiBanStatus(banResult.allOk)

                // ── Find target ──────────────────────────────────────────────
                val pid = findTargetPid()
                if (pid > 0) {
                    Log.d(TAG, "Target PID: $pid — queueing inject")
                    onInjectQueued(pid)
                } else {
                    Log.w(TAG, "Target process not found")
                    onTargetNotFound()
                }
            }
            "eject" -> {
                AntiBan.revert(TARGET_PKG)
                Log.d(TAG, "Eject + AntiBan reverted")
            }
        }

        return START_NOT_STICKY
    }

    private fun findTargetPid(): Int {
        val result = RootUtils.execRoot("pidof $TARGET_PKG")
        return result.trim().split("\\s+".toRegex()).firstOrNull()?.toIntOrNull() ?: -1
    }

    private fun onInjectQueued(pid: Int) {
        val i = Intent("com.ffpanel.INJECT_STATUS")
        i.putExtra("status", "queued")
        i.putExtra("pid", pid)
        sendBroadcast(i)
    }

    private fun onTargetNotFound() {
        val i = Intent("com.ffpanel.INJECT_STATUS")
        i.putExtra("status", "not_found")
        sendBroadcast(i)
    }

    private fun broadcastAntiBanStatus(ok: Boolean) {
        val i = Intent("com.ffpanel.INJECT_STATUS")
        i.putExtra("status", if (ok) "antiban_ok" else "antiban_partial")
        sendBroadcast(i)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
