package com.ffpanel

import android.util.Log

object RootUtils {

    private const val TAG = "FFPanel_Root"

    fun isRooted(): Boolean {
        return checkSuBinary() && checkSuCommand()
    }

    private fun checkSuBinary(): Boolean {
        val paths = arrayOf(
            "/sbin/su", "/system/su", "/system/bin/su",
            "/system/xbin/su", "/data/local/xbin/su",
            "/data/local/bin/su", "/data/local/su",
            "/su/bin/su"
        )
        return paths.any { java.io.File(it).exists() }
    }

    private fun checkSuCommand(): Boolean {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val result = p.inputStream.bufferedReader().readLine() ?: ""
            p.waitFor()
            result.contains("uid=0")
        } catch (e: Exception) {
            Log.e(TAG, "su command failed: ${e.message}")
            false
        }
    }

    fun execRoot(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (e: Exception) {
            Log.e(TAG, "execRoot failed: ${e.message}")
            ""
        }
    }

    fun isMagiskPresent(): Boolean {
        val magiskDir = java.io.File("/data/adb/magisk").exists()
        val magiskBin = java.io.File("/data/adb/magisk/magiskpolicy").exists()
        return magiskDir || magiskBin
    }

    fun isZygiskEnabled(): Boolean {
        val result = execRoot("magisk --sqlite 'SELECT value FROM settings WHERE key=\"zygisk\"'")
        return result.trim() == "1"
    }
}
