package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

/**
 * ShamikoManager
 *
 * Shamiko is a Zygisk module that hides Magisk from apps.
 * It reads its whitelist from: /data/adb/shamiko/whitelist
 *
 * Strategy:
 *  1. Verify Shamiko module is installed and enabled in Magisk.
 *  2. Add our injector package to Shamiko's whitelist so Shamiko
 *     does NOT hide root from us (we need root to function).
 *  3. Free Fire stays on DenyList → Shamiko hides root from FF.
 *
 * Shamiko whitelist = packages that CAN see root.
 * DenyList          = packages that CANNOT see root/Magisk.
 */
object ShamikoManager {

    private const val TAG = "FFPanel_Shamiko"
    private const val SHAMIKO_DIR = "/data/adb/shamiko"
    private const val WHITELIST_PATH = "/data/adb/shamiko/whitelist"
    private const val OWN_PKG = "com.ffpanel"

    fun ensure(): Boolean {
        if (!isShamikoInstalled()) {
            Log.w(TAG, "Shamiko not found — anti-ban weakened but continuing")
            return false
        }

        // Create whitelist dir if missing
        RootUtils.execRoot("mkdir -p $SHAMIKO_DIR")

        // Add own package to whitelist (so root stays visible to us)
        addToWhitelist(OWN_PKG)

        val enabled = isEnabled()
        Log.d(TAG, "Shamiko present=$enabled")
        return enabled
    }

    fun isShamikoInstalled(): Boolean {
        // Shamiko ships as a Zygisk module; look for its folder
        val moduleDir = RootUtils.execRoot("ls /data/adb/modules/ 2>/dev/null")
        return moduleDir.contains("shamiko", ignoreCase = true) ||
               java.io.File("/data/adb/shamiko").exists()
    }

    fun isEnabled(): Boolean {
        // Disabled flag = /data/adb/modules/shamiko/disable
        val disableFlag = RootUtils.execRoot(
            "test -f /data/adb/modules/shamiko/disable && echo 1 || echo 0"
        ).trim()
        return isShamikoInstalled() && disableFlag == "0"
    }

    fun addToWhitelist(pkg: String) {
        // Check if already present
        val current = RootUtils.execRoot("cat $WHITELIST_PATH 2>/dev/null")
        if (current.lines().any { it.trim() == pkg }) return

        RootUtils.execRoot("echo '$pkg' >> $WHITELIST_PATH")
        Log.d(TAG, "Added $pkg to Shamiko whitelist")
    }

    fun removeFromWhitelist(pkg: String) {
        RootUtils.execRoot("sed -i '/^${pkg}\$/d' $WHITELIST_PATH")
        Log.d(TAG, "Removed $pkg from Shamiko whitelist")
    }
}
