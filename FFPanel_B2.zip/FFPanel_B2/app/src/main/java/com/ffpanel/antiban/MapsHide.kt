package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

/**
 * MapsHide
 *
 * Free Fire reads /proc/<pid>/maps to scan for injected .so files.
 * If it sees an unexpected .so mapped into its address space → ban.
 *
 * Strategy:
 *  1. Pre-inject: rename our .so on disk to a path that looks like
 *     a system library (e.g. /system/lib64/libandroid_runtime2.so).
 *     Bind-mount it there so it survives system partition checks.
 *
 *  2. Post-inject: patch /proc/<pid>/maps via kernel module or
 *     Zygisk companion. Since we don't have a kernel module in B2,
 *     we use the userspace trick: hook the libc open/read/mmap that
 *     FF uses to read its own maps. That hook is wired in B3 (native).
 *     Here we do the filesystem-level rename so the maps entry
 *     already shows a "clean" path before the hook lands.
 *
 *  3. Use Magisk's built-in module system to register a fake system
 *     library path — Magisk's Magic Mount replaces system paths
 *     transparently, so the .so appears at a legit system path.
 */
object MapsHide {

    private const val TAG = "FFPanel_MapsHide"

    // Where our actual .so will live (injected in B3)
    private const val SO_REAL = "/data/local/tmp/ffcheat.so"

    // Disguise path — looks like a legit AOSP lib
    private const val SO_DISGUISE = "/data/local/tmp/libandroid_ext.so"

    // Magisk module overlay path (Magic Mount)
    private const val MAGISK_MODULE_DIR = "/data/adb/modules/ffpanel_hide"
    private const val SYSTEM_LIB_FAKE   = "/system/lib64/libandroid_ext.so"

    private var applied = false

    fun apply(): Boolean {
        return try {
            setupMagiskModule()
            bindMountDisguise()
            applied = true
            Log.d(TAG, "MapsHide applied")
            true
        } catch (e: Exception) {
            Log.e(TAG, "MapsHide failed: ${e.message}")
            false
        }
    }

    fun revert() {
        if (!applied) return
        RootUtils.execRoot("umount $SYSTEM_LIB_FAKE 2>/dev/null || true")
        applied = false
        Log.d(TAG, "MapsHide reverted")
    }

    /**
     * Create a minimal Magisk module that overlays a fake system lib path.
     * Magisk Magic Mount will make /system/lib64/libandroid_ext.so exist
     * in the system namespace — so when FF sees it in maps, it looks native.
     */
    private fun setupMagiskModule() {
        // Module structure
        RootUtils.execRoot("mkdir -p $MAGISK_MODULE_DIR/system/lib64")

        // Module metadata
        RootUtils.execRoot("""
            cat > $MAGISK_MODULE_DIR/module.prop << 'EOF'
id=ffpanel_hide
name=FFPanel Hide
version=v1
versionCode=1
author=sys
description=System extension
EOF
        """.trimIndent())

        // Touch the fake lib placeholder (real content injected in B3)
        RootUtils.execRoot("touch $MAGISK_MODULE_DIR/system/lib64/libandroid_ext.so")

        Log.d(TAG, "Magisk module created at $MAGISK_MODULE_DIR")
    }

    /**
     * Bind-mount SO_REAL → disguise path so maps entry shows clean name.
     * Called after the .so is placed at SO_REAL by B3 injector.
     * In B2 we set up the mount point; B3 fires the actual bind after drop.
     */
    private fun bindMountDisguise() {
        // Create placeholder at disguise path
        RootUtils.execRoot("touch $SO_DISGUISE")

        // Bind if source exists; otherwise mount point is ready for B3
        val soExists = RootUtils.execRoot(
            "test -f $SO_REAL && echo 1 || echo 0"
        ).trim() == "1"

        if (soExists) {
            RootUtils.execRoot("mount --bind $SO_REAL $SO_DISGUISE")
            Log.d(TAG, "Bind mount: $SO_REAL → $SO_DISGUISE")
        } else {
            Log.d(TAG, "SO not yet present — bind mount point ready for B3")
        }
    }

    // Called by B3 after .so is dropped at SO_REAL
    fun bindAfterDrop() {
        RootUtils.execRoot("mount --bind $SO_REAL $SO_DISGUISE")
        Log.d(TAG, "Post-drop bind mount applied")
    }
}
