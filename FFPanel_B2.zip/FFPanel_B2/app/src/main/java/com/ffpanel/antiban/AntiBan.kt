package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

/**
 * AntiBan — master controller
 * Wires all four layers: Shamiko, DenyList, process spoof, maps hide.
 * Call AntiBan.apply() before any inject attempt.
 */
object AntiBan {

    private const val TAG = "FFPanel_AntiBan"

    data class AntiBanResult(
        val shamiko: Boolean,
        val denyList: Boolean,
        val processSpoof: Boolean,
        val mapsHide: Boolean
    ) {
        val allOk get() = shamiko && denyList && processSpoof && mapsHide
        override fun toString() =
            "shamiko=$shamiko | denyList=$denyList | spoof=$processSpoof | mapsHide=$mapsHide"
    }

    fun apply(targetPkg: String = "com.dts.freefireth"): AntiBanResult {
        Log.d(TAG, "Applying anti-ban for $targetPkg")

        val shamiko  = ShamikoManager.ensure()
        val denyList = DenyListManager.addPackage(targetPkg)
        val spoof    = ProcessSpoof.apply()
        val maps     = MapsHide.apply()

        val result = AntiBanResult(shamiko, denyList, spoof, maps)
        Log.d(TAG, "AntiBan result: $result")

        return result
    }

    // Reverse everything cleanly (for safe-mode toggle in B7)
    fun revert(targetPkg: String = "com.dts.freefireth") {
        DenyListManager.removePackage(targetPkg)
        ProcessSpoof.revert()
        MapsHide.revert()
        Log.d(TAG, "AntiBan reverted")
    }
}
