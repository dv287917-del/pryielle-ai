package com.ffpanel.antiban

import android.util.Log
import com.ffpanel.RootUtils

/**
 * DenyListManager
 *
 * Magisk DenyList = packages that get a "clean" process view:
 * Magisk hides itself, su binaries, and injected modules from them.
 *
 * We add Free Fire to DenyList so it can't see Magisk at all.
 * This is the core hide layer — Shamiko enforces it at the Zygisk level.
 *
 * Commands use `magisk --denylist` CLI (Magisk 24+).
 */
object DenyListManager {

    private const val TAG = "FFPanel_DenyList"

    // Packages to always deny
    private val DEFAULT_DENY = listOf(
        "com.dts.freefireth",      // Free Fire India
        "com.dts.freefiremax"      // Free Fire MAX (same anti-cheat)
    )

    fun addPackage(pkg: String): Boolean {
        return try {
            // Enable DenyList mode first (enforce mode)
            enableDenyList()

            val out = RootUtils.execRoot("magisk --denylist add $pkg")
            Log.d(TAG, "DenyList add $pkg: $out")

            // Verify
            isOnDenyList(pkg)
        } catch (e: Exception) {
            Log.e(TAG, "DenyList add failed: ${e.message}")
            false
        }
    }

    fun removePackage(pkg: String) {
        RootUtils.execRoot("magisk --denylist rm $pkg")
        Log.d(TAG, "DenyList removed $pkg")
    }

    fun applyDefaults(): Boolean {
        enableDenyList()
        var ok = true
        for (pkg in DEFAULT_DENY) {
            ok = ok && addPackage(pkg)
        }
        return ok
    }

    fun isOnDenyList(pkg: String): Boolean {
        val list = RootUtils.execRoot("magisk --denylist ls")
        return list.contains(pkg)
    }

    fun getDenyList(): List<String> {
        return RootUtils.execRoot("magisk --denylist ls")
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }

    // Switch Magisk to "enforce" mode (required for DenyList to work)
    private fun enableDenyList() {
        // Check current mode
        val mode = RootUtils.execRoot(
            "magisk --sqlite 'SELECT value FROM settings WHERE key=\"denylist\"'"
        ).trim()

        if (mode != "1") {
            RootUtils.execRoot(
                "magisk --sqlite 'REPLACE INTO settings (key,value) VALUES(\"denylist\",1)'"
            )
            Log.d(TAG, "DenyList enforce mode enabled")
        }
    }
}
