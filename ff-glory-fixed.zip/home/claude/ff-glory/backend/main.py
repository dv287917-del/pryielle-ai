# main.py — FF Glory Bot Backend (FastAPI)

from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
import firebase_admin
from firebase_admin import credentials, firestore
import secrets
import datetime
import os
from dotenv import load_dotenv

load_dotenv()

# Firebase init
cred = credentials.Certificate("firebase_key.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

app = FastAPI(title="FF Glory Bot Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

security = HTTPBearer()

ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "CHANGE_THIS_SECRET")
ADMIN_EMAIL = "workwithpryielle@gmail.com"

# ─── Auth ───────────────────────────────────────────────

def verify_admin(creds: HTTPAuthorizationCredentials = Depends(security)):
    if creds.credentials != ADMIN_TOKEN:
        raise HTTPException(status_code=403, detail="Unauthorized")
    return True

# ─── Admin Routes ────────────────────────────────────────

@app.post("/admin/generate-key")
def generate_key(days: int, _=Depends(verify_admin)):
    if days not in [7, 15, 20, 30]:
        raise HTTPException(status_code=400, detail="Days must be 7, 15, 20 or 30")

    key = secrets.token_urlsafe(12).upper().replace("-", "").replace("_", "")[:16]
    expiry = datetime.datetime.utcnow() + datetime.timedelta(days=days)

    db.collection("keys").document(key).set({
        "key": key,
        "days": days,
        "expiry": expiry,
        "used": False,
        "activated_by": None,
        "created_at": datetime.datetime.utcnow()
    })

    return {
        "key": key,
        "days": days,
        "expiry": expiry.strftime("%Y-%m-%d %H:%M UTC")
    }

@app.get("/admin/keys")
def list_keys(_=Depends(verify_admin)):
    keys = db.collection("keys").stream()
    result = []
    now = datetime.datetime.utcnow()

    for k in keys:
        data = k.to_dict()
        expiry = data["expiry"]
        if hasattr(expiry, "replace"):
            expiry_dt = expiry.replace(tzinfo=None)
        else:
            expiry_dt = expiry
        days_left = (expiry_dt - now).days
        data["days_left"] = max(0, days_left)
        data["expired"] = days_left <= 0
        data["expiry"] = str(expiry_dt)
        result.append(data)

    return result

@app.delete("/admin/delete-key/{key}")
def delete_key(key: str, _=Depends(verify_admin)):
    doc = db.collection("keys").document(key).get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Key not found")
    db.collection("keys").document(key).delete()
    return {"deleted": True, "key": key}

@app.patch("/admin/revoke-key/{key}")
def revoke_key(key: str, _=Depends(verify_admin)):
    doc = db.collection("keys").document(key).get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Key not found")
    # Set expiry to past
    db.collection("keys").document(key).update({
        "expiry": datetime.datetime.utcnow() - datetime.timedelta(days=1)
    })
    return {"revoked": True, "key": key}

# ─── Public Routes ───────────────────────────────────────

@app.post("/verify-key")
def verify_key(key: str, device_id: str):
    key = key.upper().strip()
    doc = db.collection("keys").document(key).get()

    if not doc.exists:
        raise HTTPException(status_code=404, detail="Invalid key")

    data = doc.to_dict()
    expiry = data["expiry"]
    now = datetime.datetime.utcnow()

    if hasattr(expiry, "replace"):
        expiry_dt = expiry.replace(tzinfo=None)
    else:
        expiry_dt = expiry

    if now > expiry_dt:
        raise HTTPException(status_code=403, detail="Key expired")

    if data["used"] and data["activated_by"] != device_id:
        raise HTTPException(status_code=403, detail="Key already used on another device")

    # Activate key
    db.collection("keys").document(key).update({
        "used": True,
        "activated_by": device_id,
        "activated_at": now
    })

    days_left = (expiry_dt - now).days

    return {
        "valid": True,
        "days_left": max(1, days_left),
        "expiry": expiry_dt.strftime("%Y-%m-%d"),
        "device_id": device_id
    }

@app.get("/key-status")
def key_status(key: str, device_id: str):
    key = key.upper().strip()
    doc = db.collection("keys").document(key).get()

    if not doc.exists:
        raise HTTPException(status_code=404, detail="Invalid key")

    data = doc.to_dict()
    expiry = data["expiry"]
    now = datetime.datetime.utcnow()

    if hasattr(expiry, "replace"):
        expiry_dt = expiry.replace(tzinfo=None)
    else:
        expiry_dt = expiry

    if data["activated_by"] and data["activated_by"] != device_id:
        raise HTTPException(status_code=403, detail="Key bound to another device")

    days_left = (expiry_dt - now).days
    expired = days_left <= 0

    return {
        "valid": not expired,
        "days_left": max(0, days_left),
        "expiry": expiry_dt.strftime("%Y-%m-%d"),
        "expired": expired
    }

@app.get("/health")
def health():
    return {"status": "ok", "admin": ADMIN_EMAIL}
