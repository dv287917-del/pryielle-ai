# ⚡ FF Glory

Free Fire Player Stats Tracker — Working app with real data from Garena.

---

## Kya karta hai yeh app

- Player naam ya UID se search karo
- Profile dekho — level, likes, region, last login, pet
- BR Career + Ranked stats — Solo/Duo/Squad — W%, K/D, damage, headshots
- Items dekho — outfit, weapons, skills, pet
- Key-based access — tu admin hai, users ko key deta hai

---

## Architecture

```
[Flutter App (Android)]
        |
        | HTTP
        v
[API Server — Node.js]          ← @arbakti_store/freefire-api use karta hai
        |
        | Protobuf / internal endpoints
        v
[Garena Servers]                ← real player data

[Backend — FastAPI + Firebase]  ← sirf key management ke liye
```

---

## Setup Order

### Step 1 — API Server deploy karo (Railway.app — free)

```bash
# Railway pe new project banao
# GitHub repo connect karo
# Root directory: api-server
# Start command: node server.js

# Ya local test:
cd api-server
npm install
npm start
# Running on http://localhost:3000
```

Railway deploy hone ke baad URL milega, jaise:
`https://ff-glory-api.railway.app`

### Step 2 — Backend deploy karo (key management)

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# .env mein daalo:
# ADMIN_TOKEN=koi_bhi_secret_string

# Railway/Render pe deploy karo
# Start command: uvicorn main:app --host 0.0.0.0 --port 8000
```

### Step 3 — Flutter app configure karo

`flutter-app/lib/config.dart` mein:
```dart
static const String backendUrl = 'https://ff-glory-api.railway.app';
// ^ Step 1 ka URL daalo
```

### Step 4 — APK build karo

```bash
# GitHub pe push karo — Actions automatically build karega
# Ya local:
cd flutter-app
flutter pub get
flutter build apk --release
```

APK milega: `flutter-app/build/app/outputs/flutter-apk/app-release.apk`

### Step 5 — Keys banao

```bash
# Backend deploy hone ke baad
curl -X POST "https://your-backend.railway.app/admin/generate-key?days=30" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"

# Response:
# {"key": "ABCD1234EFGH5678", "days": 30, "expiry": "2025-11-24"}
```

---

## API Endpoints (Node.js proxy)

| Method | Path | Kya karta hai |
|--------|------|---------------|
| GET | `/health` | Server alive check |
| GET | `/search?q=PlayerName` | Player search by nickname |
| GET | `/profile/:uid` | Full profile data |
| GET | `/stats/:uid/br/career` | BR career stats |
| GET | `/stats/:uid/br/ranked` | BR ranked stats |
| GET | `/stats/:uid/cs/career` | CS career stats |
| GET | `/items/:uid` | Equipped items |

---

## Key Management (FastAPI backend)

| Method | Path | Auth |
|--------|------|------|
| POST | `/admin/generate-key?days=30` | Admin token |
| GET | `/admin/keys` | Admin token |
| DELETE | `/admin/delete-key/{key}` | Admin token |
| PATCH | `/admin/revoke-key/{key}` | Admin token |
| POST | `/verify-key?key=X&device_id=Y` | Public |
| GET | `/key-status?key=X&device_id=Y` | Public |

---

## Files

```
ff-glory/
├── flutter-app/          → Android app (Flutter)
│   ├── lib/
│   │   ├── main.dart
│   │   ├── config.dart   ← backendUrl yahan daalo
│   │   ├── services/
│   │   │   └── ff_api.dart
│   │   └── screens/
│   │       ├── key_screen.dart
│   │       ├── home_screen.dart
│   │       ├── player_screen.dart
│   │       └── settings_screen.dart
│   └── pubspec.yaml
├── api-server/           → Node.js FF data proxy
│   ├── server.js
│   └── package.json
├── backend/              → Python key management
│   ├── main.py
│   └── requirements.txt
└── .github/workflows/
    └── build.yml         → Auto APK build
```
