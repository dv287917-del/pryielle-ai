// api-server/server.js
// FF Glory API Proxy — @arbakti_store/freefire-api ko REST mein wrap karta hai
// Flutter app is se baat karta hai

const express = require('express');
const cors = require('cors');
const FreeFireAPI = require('@arbakti_store/freefire-api');

const app = express();
app.use(cors());
app.use(express.json());

const api = new FreeFireAPI();
const PORT = process.env.PORT || 3000;

// ─── Health ──────────────────────────────────────────────────────────────────

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'FF Glory API Proxy' });
});

// ─── Search ──────────────────────────────────────────────────────────────────

app.get('/search', async (req, res) => {
  const { q } = req.query;
  if (!q) return res.status(400).json({ detail: 'q parameter required' });

  try {
    const results = await api.searchAccount(q);
    // normalize to flat array
    const players = Array.isArray(results) ? results : [results];
    res.json(players.map(p => ({
      uid: `${p.accountid || p.uid || ''}`,
      nickname: p.nickname || 'Unknown',
      level: p.level || 0,
      region: p.region || '',
    })));
  } catch (err) {
    console.error('[search]', err.message);
    res.status(500).json({ detail: err.message });
  }
});

// ─── Profile ─────────────────────────────────────────────────────────────────

app.get('/profile/:uid', async (req, res) => {
  const { uid } = req.params;
  try {
    const data = await api.getPlayerProfile(uid);
    res.json(data);
  } catch (err) {
    console.error('[profile]', err.message);
    res.status(500).json({ detail: err.message });
  }
});

// ─── Stats ────────────────────────────────────────────────────────────────────
// GET /stats/:uid/br/career
// GET /stats/:uid/br/ranked
// GET /stats/:uid/cs/career
// GET /stats/:uid/cs/ranked

app.get('/stats/:uid/:mode/:matchType', async (req, res) => {
  const { uid, mode, matchType } = req.params;
  // validate
  if (!['br', 'cs'].includes(mode)) {
    return res.status(400).json({ detail: 'mode must be br or cs' });
  }
  if (!['career', 'ranked', 'normal'].includes(matchType)) {
    return res.status(400).json({ detail: 'matchType must be career/ranked/normal' });
  }

  try {
    const data = await api.getPlayerStats(uid, mode, matchType);
    // BR returns {solo, duo, squad} structure
    // CS returns {csstats: {...}} structure
    res.json(data);
  } catch (err) {
    console.error('[stats]', err.message);
    res.status(500).json({ detail: err.message });
  }
});

// ─── Items ───────────────────────────────────────────────────────────────────

app.get('/items/:uid', async (req, res) => {
  const { uid } = req.params;
  try {
    const data = await api.getPlayerItems(uid);
    res.json(data);
  } catch (err) {
    console.error('[items]', err.message);
    res.status(500).json({ detail: err.message });
  }
});

// ─── Start ───────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`FF Glory API Proxy running on port ${PORT}`);
});
