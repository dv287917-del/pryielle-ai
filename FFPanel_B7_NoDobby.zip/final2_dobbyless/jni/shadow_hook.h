// shadow_hook.h — manual inline trampoline hook for ARM64 + ARM32
// No external library. Replaces Dobby completely.
// API: ShadowHook / ShadowDestroy (drop-in for DobbyHook / DobbyDestroy)

#pragma once
#include <stdint.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <android/log.h>

#define SH_TAG  "ShadowHook"
#define SH_LOGI(...) __android_log_print(ANDROID_LOG_INFO,  SH_TAG, __VA_ARGS__)
#define SH_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, SH_TAG, __VA_ARGS__)

#if defined(__aarch64__)
// ARM64: ldr x17, #8  +  br x17  +  <8-byte addr>  = 16 bytes
#  define TRAMP_PATCH_SIZE   16
#  define TRAMP_TOTAL_SIZE   (TRAMP_PATCH_SIZE + 8 + TRAMP_PATCH_SIZE)
// extra 8 for the return address literal after the trampoline jump
static inline void sh_write_abs_jump(uint8_t* dst, uint64_t target) {
    uint32_t ldr = 0x58000051; // ldr x17, #8
    uint32_t br  = 0xD61F0220; // br  x17
    memcpy(dst + 0, &ldr, 4);
    memcpy(dst + 4, &br,  4);
    memcpy(dst + 8, &target, 8);
}
#elif defined(__arm__)
// ARM32 Thumb2: LDR PC, [PC, #0]  +  <4-byte addr>  = 8 bytes
#  define TRAMP_PATCH_SIZE   8
#  define TRAMP_TOTAL_SIZE   (TRAMP_PATCH_SIZE + 4 + TRAMP_PATCH_SIZE)
static inline void sh_write_abs_jump(uint8_t* dst, uint32_t target) {
    // Thumb2 LDR PC, [PC, #0] encoding: F000 F8DF + addr
    uint16_t ldr_hi = 0xF8DF, ldr_lo = 0xF000;
    memcpy(dst + 0, &ldr_hi, 2);
    memcpy(dst + 2, &ldr_lo, 2);
    memcpy(dst + 4, &target, 4);
}
#endif

static inline int sh_set_prot(void* addr, size_t len, int prot) {
    uintptr_t pg = (uintptr_t)addr & ~((uintptr_t)getpagesize() - 1);
    return mprotect((void*)pg, (len + getpagesize() * 2), prot);
}

typedef struct {
    void*   target;
    uint8_t saved[TRAMP_PATCH_SIZE];
    uint8_t tramp[TRAMP_TOTAL_SIZE];
    int     active;
} ShadowEntry;

#define SH_MAX 16
static ShadowEntry _sh_table[SH_MAX];
static int         _sh_cnt = 0;

static inline int ShadowHook(void* target, void* replace, void** orig_out) {
    if (!target || !replace || !orig_out) return -1;
    if (_sh_cnt >= SH_MAX) { SH_LOGE("table full"); return -1; }

    ShadowEntry* e = &_sh_table[_sh_cnt];
    e->target = target;
    e->active = 0;

    // Save original bytes
    memcpy(e->saved, target, TRAMP_PATCH_SIZE);

    // Build trampoline: saved bytes + abs jump to target+PATCH_SIZE
    memcpy(e->tramp, e->saved, TRAMP_PATCH_SIZE);
#if defined(__aarch64__)
    sh_write_abs_jump(e->tramp + TRAMP_PATCH_SIZE,
                      (uint64_t)(uintptr_t)target + TRAMP_PATCH_SIZE);
#else
    sh_write_abs_jump(e->tramp + TRAMP_PATCH_SIZE,
                      (uint32_t)(uintptr_t)target + TRAMP_PATCH_SIZE);
#endif

    // Make trampoline RWX
    if (sh_set_prot(e->tramp, TRAMP_TOTAL_SIZE, PROT_READ|PROT_WRITE|PROT_EXEC) != 0) {
        SH_LOGE("mprotect tramp failed"); return -1;
    }
    __builtin___clear_cache((char*)e->tramp,
                            (char*)e->tramp + TRAMP_TOTAL_SIZE);

    // Patch target with abs jump to replace
    if (sh_set_prot(target, TRAMP_PATCH_SIZE, PROT_READ|PROT_WRITE|PROT_EXEC) != 0) {
        SH_LOGE("mprotect target failed"); return -1;
    }
    uint8_t patch[TRAMP_PATCH_SIZE];
#if defined(__aarch64__)
    sh_write_abs_jump(patch, (uint64_t)(uintptr_t)replace);
#else
    sh_write_abs_jump(patch, (uint32_t)(uintptr_t)replace);
#endif
    memcpy(target, patch, TRAMP_PATCH_SIZE);
    __builtin___clear_cache((char*)target,
                            (char*)target + TRAMP_PATCH_SIZE);

    *orig_out = (void*)e->tramp;
    e->active = 1;
    _sh_cnt++;
    SH_LOGI("OK %p -> %p tramp=%p", target, replace, e->tramp);
    return 0;
}

static inline int ShadowDestroy(void* target) {
    for (int i = 0; i < _sh_cnt; i++) {
        ShadowEntry* e = &_sh_table[i];
        if (e->target == target && e->active) {
            if (sh_set_prot(target, TRAMP_PATCH_SIZE,
                            PROT_READ|PROT_WRITE|PROT_EXEC) != 0) return -1;
            memcpy(target, e->saved, TRAMP_PATCH_SIZE);
            __builtin___clear_cache((char*)target,
                                    (char*)target + TRAMP_PATCH_SIZE);
            e->active = 0;
            SH_LOGI("restored %p", target);
            return 0;
        }
    }
    SH_LOGE("not found: %p", target);
    return -1;
}
